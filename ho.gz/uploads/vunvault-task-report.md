# VUNVAULT — Part 1 (Tasks 1–20) completion report

Repository: `/home/user/vunvault` (pnpm 9.15.0 + Turborepo, Node 22 pinned via `.nvmrc` / `engines`).
All twenty Part-1 tasks are implemented. Part 2's addendum tasks (20b, 20c, 20d) are **not** started.

## Verification

| Check | Command | Result |
| --- | --- | --- |
| Typecheck | `pnpm typecheck` (`turbo run typecheck`) | **10 / 10 packages pass** |
| Lint | `pnpm lint` (`turbo run lint`) | **10 / 10 packages pass, 0 errors, 0 warnings** |
| Tests | `pnpm test` (`turbo run test`) | **9 / 9 test tasks pass — 299 tests** |
| Stack guards | `pnpm verify` | `OK: verify-no-html` · `OK: forbidden-stack` |
| Formatting | `pnpm format:check` | All files use Prettier code style |
| Tailwind v4 | compile `packages/ui/src/styles/index.css` | 18.5 KB output; `bg-brand`, `rounded-field`, `ease-vv`, `bg-grad-*`, `animate-vv-*`, `.vv-preloader*`, reduced-motion block all emitted |
| Drizzle schema | `drizzle-kit generate` (temp out-dir, output deleted) | 39 enum types, 28 RLS-enabled tables, generated identity/stored columns, all checks; `.existing()` view correctly excluded |

Test counts per package: `@vunvault/ui` 101 · `@vunvault/db` 78 · `@vunvault/contracts` 66 · `@vunvault/lib` 54.

> Sandbox note: verification ran on Node 22.23.3 (installed to `/tmp`) because the workspace
> Node was v20 and `engines.node: ">=22 <23"` + `engine-strict=true` are required by Task 1.

---

## Per-task reports

### Task 1 complete.
Files created: `package.json`, `pnpm-workspace.yaml`, `turbo.json`, `.nvmrc`, `.npmrc`, `.gitignore`, `.editorconfig`, `.env.example`, `README.md`, `docs/.gitkeep`.
Files modified: none.
Dependencies added: `turbo@^2.5.4`, `typescript` (catalog `~5.5.4`), `prettier@^3.4.2` — root devDependencies only.

### Task 2 complete.
Files created: `packages/config/package.json`, `packages/config/tsconfig.base.json`, `packages/config/tsconfig.react-lib.json`, `packages/config/tsconfig.next.json`, `packages/config/tsconfig.node.json`, `packages/config/eslint.base.mjs`, `packages/config/eslint.next.mjs`, `packages/config/eslint.node.mjs`, `packages/config/prettier.config.mjs`, `packages/config/README.md`, `eslint.config.mjs` (root), `prettier.config.mjs` (root).
Files modified: none.
Dependencies added: `@eslint/js`, `@next/eslint-plugin-next`, `eslint` (catalog), `eslint-config-prettier`, `eslint-plugin-jsx-a11y`, `eslint-plugin-react`, `eslint-plugin-react-hooks`, `globals`, `typescript-eslint` (all in `packages/config`).
Verified: `tsc -p tsconfig.base.json --showConfig` prints `strict: true` and `noUncheckedIndexedAccess: true` and exits 0; `eslint --print-config eslint.config.mjs` resolves 265 rules.

### Task 3 complete.
Files created (36): `apps/web`, `apps/api`, `apps/scan-worker`, `apps/broadcast-worker`, `apps/maintenance-worker`, `packages/ui`, `packages/lib`, `packages/db`, `packages/contracts` — each with `package.json`, `tsconfig.json`, `eslint.config.mjs`, `src/index.ts` (`export {};`).
Files modified: none.
Dependencies added: per workspace `@vunvault/config`, `typescript`, `eslint`, `vitest` (devDependencies) plus the specified `workspace:*` cross-dependencies (`web → ui/lib/contracts`, `api → db/contracts`, workers `→ contracts`, `ui → lib`, `lib → contracts`, `contracts → db`).
Verified: `turbo` reports all 10 packages for typecheck/lint.

### Task 4 complete.
Files created (16): `vitest.shared.ts`, `vitest.setup.dom.ts`, `vitest.workspace.ts`, `packages/ui/vitest.config.ts`, `packages/lib/vitest.config.ts`, `packages/db/vitest.config.ts`, `packages/contracts/vitest.config.ts`, `scripts/verify-no-html.mjs`, `scripts/verify-forbidden-stack.mjs`, `.husky/pre-commit`, `.husky/commit-msg`, `.lintstagedrc.json`, `commitlint.config.mjs`, `.github/pull_request_template.md`, `packages/{ui,lib,db,contracts}/src/smoke.test.ts`.
Files modified: `package.json` (root) — added `prepare`, `verify` scripts and devDependencies.
Dependencies added: `vitest` (catalog), `jsdom`, `@testing-library/react`, `@testing-library/jest-dom`, `@testing-library/user-event`, `husky`, `lint-staged`, `@commitlint/cli`, `@commitlint/config-conventional`.
Verified: `pnpm verify` prints both `OK:` lines; the four smoke tests run and pass.

### Task 5 complete.
Files created: `packages/ui/src/styles/tokens.css`, `theme.css`, `base.css`, `motion.css`, `index.css`, `packages/ui/src/tokens.ts`, `packages/ui/src/tokens.test.ts`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/package.json` (exports `./styles.css`, `tailwindcss` peerDependency).
Dependencies added: `tailwindcss` (catalog) as peer + devDependency in `packages/ui`.
Verified: token-consistency test passes (every `tokens.ts` colour/radius/easing appears in `tokens.css`; import order asserted); the whole stylesheet compiles through Tailwind v4.

### Task 6 complete.
Files created: `packages/lib/src/cn.ts`, `format.ts`, `ids.ts`, `money.ts`, `assert.ts`, `format.test.ts`, `ids.test.ts`, `money.test.ts`, `core.test.ts`.
Files modified: `packages/lib/src/index.ts`, `packages/lib/package.json`.
Dependencies added: `clsx`, `tailwind-merge`.
Verified: all specified expectations asserted verbatim (`$2,499.00`, `$899.00`, `$2,499`, `32362050`, `24 Sep · 06:12 UTC`, `18 Aug 2026`, `VV-INV-2026-0841`, `JOB-4471`, `VV-PT-000000`, `VV-CL-48210`, `parseJobCode("nope") === null`); FX conversion is BigInt-only (1e8 scale, half-up).

### Task 7 complete.
Files created: `packages/lib/src/api/errors.ts`, `api/client.ts`, `api/query-keys.ts`, `api/query-client.ts`, `api/client.test.ts`.
Files modified: `packages/lib/src/index.ts`, `packages/lib/package.json`.
Dependencies added: `@tanstack/react-query@^5`.
Verified: `credentials: "include"` on every call; `x-csrf-token` from `vv_csrf` on POST/PUT/PATCH/DELETE but never GET; `Authorization` stripped; 204 → `undefined`; error envelope → `ApiError` with `code` + `requestId`; 401 calls `onUnauthorized` and still throws; `AbortSignal` forwarded; retry policy never retries 4xx.

### Task 8 complete.
Files created: `packages/ui/src/components/button.tsx`, `badge.tsx`, `status-pill.tsx`, `spinner.tsx`, `button.test.tsx`, `badge.test.tsx`, `status-pill.test.tsx`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/package.json`.
Dependencies added: `class-variance-authority`, `@radix-ui/react-slot`.
Verified: copy used verbatim (`Provision New Member`, `Paid`, `Pending`, `Critical`, `SYS: OPERATIONAL`); `aria-label` is required by the type when `size="icon"`; `console.error` spy asserts zero React warnings.

### Task 9 complete.
Files created: `packages/ui/src/components/card.tsx`, `kpi-card.tsx`, `eyebrow.tsx`, `progress-bar.tsx`, `skeleton.tsx`, `empty-state.tsx`, `surfaces.test.tsx`.
Files modified: `packages/ui/src/index.ts`.
Dependencies added: `lucide-react`.
Verified: verbatim copy (`Active Team Members`, `▲ 3 onboarded this month`, `MFA Enrolment` + `%`, `2 accounts without MFA`, `Active Staff Roster — Security Analysts & Operators`, `Identity, Access & Provisioning`, the EmptyState title/description/`Reset Filters`); `KpiGrid` requires `aria-label`.

### Task 10 complete.
Files created: `packages/ui/src/components/label.tsx`, `input.tsx`, `select.tsx`, `checkbox.tsx`, `switch.tsx`, `form.tsx`, `form-controls.test.tsx`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/package.json`.
Dependencies added: `@radix-ui/react-label`, `@radix-ui/react-select`, `@radix-ui/react-checkbox`, `@radix-ui/react-switch`; `react-hook-form`, `@hookform/resolvers`, `zod` (catalog, dev).
Verified: RHF + Zod integration test with the exact schema — submitting empty renders both messages (`Enter the member's full name`, `Enter a valid work email`) as `role="alert"`, `aria-invalid` + `aria-describedby` are wired, and valid values submit; no `useState` holds a form value.

### Task 11 complete.
Files created: `packages/ui/src/components/dialog.tsx`, `toast.tsx`, `tooltip.tsx`, `packages/ui/src/lib/toast-store.ts`, `overlays.test.tsx`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/package.json`.
Dependencies added: `@radix-ui/react-dialog`, `@radix-ui/react-toast`, `@radix-ui/react-tooltip`, `zustand`.
Verified: Escape closes the dialog **and** focus returns to the trigger; `body.nav-open` is applied while open and removed on close; `crit` toast renders `role="alert"` (foreground) and `ok` renders `role="status"`; max 4 visible with oldest dismissed first; verbatim copy (`Provision New Team Member`, the long description, `Save Draft`, `Send Secure Invitation`, `Invitation sent` / `Secure invitation issued.`, `Release locked` / `Complete the review gate first.`).

### Task 12 complete.
Files created: `packages/ui/src/components/data-table.tsx`, `table-footer.tsx`, `select-column.tsx`, `data-table.types.ts`, `data-table.test.tsx`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/package.json`.
Dependencies added: `@tanstack/react-table@^8`.
Verified: hidden caption carries the verbatim screen-reader text; the six verbatim column headers render in order; `aria-sort` on sortable headers only; 6 skeleton rows while loading; EmptyState inside the table with the verbatim copy and `colspan`; indeterminate "Select all rows"; row click fires for the row but not for controls inside it; keyboard activation via Enter/Space with rows kept as `<tr>` (no `role="button"`); `Showing 10 of 24 members`; pager disabled at both ends.

### Task 13 complete.
Files created: `packages/ui/src/components/logo.tsx`, `preloader.tsx`, `preloader.css`, `brand.test.tsx`.
Files modified: `packages/ui/src/index.ts`, `packages/ui/src/styles/index.css` (preloader import appended last), `packages/ui/src/tokens.test.ts` (the Task 5 import-order assertion now expects the sixth import).
Dependencies added: none.
Verified: `role="status"` + `aria-label="Loading VUNVAULT"` + caption `Establishing secure channel`; fake-timer test proves the panel gains `is-hidden` at 4000 ms, unmounts at 4700 ms and calls `onDone` exactly once (and not at all when unmounted early); reduced motion collapses the sequence to 800 ms; the logo SVG is referenced as `/brand/logo.svg` and never created.

### Task 14 complete.
Files created: `packages/db/drizzle.config.ts`, `src/enum-values.ts`, `src/schema/_enums.ts`, `src/schema/_columns.ts`, `src/schema/index.ts`, `src/client.ts`, `src/migrate.ts`, `sql/.gitkeep`, `sql/0000_extensions.sql`, `src/enum-values.test.ts`.
Files modified: `packages/db/src/index.ts`, `packages/db/package.json` (exports `.` + `./enum-values`, scripts `db:generate` / `db:migrate`).
Dependencies added: `drizzle-orm` (catalog), `postgres`; `drizzle-kit` (catalog), `tsx` (dev).
Verified: `enum-values.ts` has **zero imports** — `@vunvault/contracts` builds 39 Zod enums from it without pulling `drizzle-orm`; all 39 tuples pinned by count and value in tests; `createDb` uses `prepare: false`, `max: 10`, `ssl: "require"`; the RLS policy is documented in `_columns.ts`.

### Task 15 complete.
Files created: `packages/db/src/schema/identity.ts`, `src/schema/identity.test.ts`.
Files modified: `packages/db/src/schema/index.ts`, `packages/db/src/schema/_columns.ts`.
Dependencies added: none.
Verified: `organizations`, `profiles` (id → `auth.users.id` ON DELETE CASCADE, citext unique email, `mfa_methods` array, soft delete), `staff_invitations` (hashed token only, 5-key checklist default), `webauthn_credentials` (bytea public key), `consent_records` (actor check); RLS enabled and zero permissive policies on all five.

### Task 16 complete.
Files created: `packages/db/src/schema/scans.ts`, `src/schema/scans.test.ts`.
Files modified: `packages/db/src/schema/index.ts`.
Dependencies added: none.
Verified: `job_number` identity starts at 4472; `job_code` is `GENERATED ALWAYS AS ('JOB-' || lpad(job_number::text, 4, '0')) STORED` and unique (asserted from the Drizzle model *and* from generated SQL); `VV-PT-` reference generation; unique `(job_id, attempt)` and `(job_id, check_key)`; `scan_jobs_release_lock_check` and `scan_jobs_progress_range`; `review_decisions_note_length >= 10`; no raw scanner output column.

### Task 17 complete.
Files created: `packages/db/src/schema/billing.ts`, `packages/db/sql/0017_ledger_constraints.sql`, `src/schema/billing.test.ts`.
Files modified: `packages/db/src/schema/index.ts`.
Dependencies added: none.
Verified: **no** `card_number` / `pan` / `cvc` column anywhere in the schema; every `settlement_currency` is `char(3) NOT NULL DEFAULT 'USD'` with a pinning check; every `*_usd_cents` is a bigint in number mode; local currency appears only in `fx_quotes`; `invoice_balances` declared `.existing()` with its view DDL, the deferred double-entry constraint trigger and the two immutability triggers in the SQL file.

### Task 18 complete.
Files created: `packages/db/src/schema/content.ts`, `src/schema/audit.ts`, `packages/db/sql/0018_audit_chain.sql`, `src/schema/content-audit.test.ts`.
Files modified: `packages/db/src/schema/index.ts`.
Dependencies added: none.
Verified: `audit_entries` has `seq, prev_hash, hash, signature, key_id` (+ `sealed_details`/`nonce` as bytea, `ip` as inet); `seq` is the identity primary key and `hash` is unique; the SQL file refuses UPDATE/DELETE/TRUNCATE on both audit tables and `content_reviews`, links inserts to the head hash under `pg_advisory_xact_lock(7340481)`, seeds the guarded genesis row from `digest('VUNVAULT-GENESIS-2024-03-01','sha256')`, and carries the WORM retention comment.

### Task 19 complete.
Files created: `packages/contracts/src/common.ts`, `enums.ts`, `permissions.ts`, `auth.ts`, `users.ts`, `scans.ts`, `profile.ts`, `routes-a.ts`, `contracts-a.test.ts`, `fixtures/users.ts`, `fixtures/scans.ts`, `fixtures/profile.ts`, `fixtures/index.ts`, `README.md`.
Files modified: `packages/contracts/src/index.ts`, `packages/contracts/package.json` (exports `.` + `./fixtures/*`).
Dependencies added: `zod` (catalog).
Verified: every schema has a fixture-backed parse-success test and at least one parse-failure test; `GateDecisionBody` with `approve_release` and one unchecked step fails at path `["checks"]` with the exact message, while `hold_remediation`/`reject_archive` pass with the checklist open; all 27 documented routes present in `ROUTES_A`; no `drizzle-orm` import anywhere in the package.

### Task 20 complete.
Files created: `packages/contracts/src/billing.ts`, `src/content.ts`, `src/audit.ts`, `src/contact.ts`, `src/routes-b.ts`, `src/contracts-b.test.ts`, `fixtures/billing.ts`, `fixtures/content.ts`, `fixtures/audit.ts`.
Files modified: `packages/contracts/fixtures/index.ts`, `packages/contracts/src/index.ts`. `src/enums.ts` needed **no** edit — every Zod enum wrapper Task 20 consumes already existed from Task 19.
Dependencies added: none.
Verified:
* every schema has a fixture-backed parse-success test **and** at least one parse-failure test (66 tests in the package);
* `CheckoutBody` with `channel: "mpesa"` + `provider: "stripe"` fails at path `["provider"]`;
* `ModerationActionBody` with `action: "reject"` and no note fails at `["note"]`, and `action: "schedule"` without `scheduledFor` fails at `["scheduledFor"]`;
* `FxQuote.settlementCurrency` rejects `KES`, `NGN`, `GHS`, `ZAR`, `usd` and `""` — only `"USD"` parses (same for `Subscription`, `Invoice` and `CheckoutResponse`);
* `PaymentMethodView` cannot carry card data: a 16-digit `last4` fails, and injected `cardNumber` / `cvc` keys are stripped;
* the ten audit fixtures chain correctly (`auditEntries[i].prevHash === auditEntries[i+1].hash`, newest first, `seq` counting down from `chainStatus.totalEntries`);
* no `PUT`/`PATCH`/`DELETE` route exists for audit entries, and `ROUTES_B` documents all 22 endpoints;
* `ContactBody.consent` only accepts `true` with the message `Consent is required`; both consent presets parse and `strictlyNecessary: false` is refused;
* no crypto-related currency, provider, channel or route anywhere (asserted over the serialised `ROUTES_B`).

One catalogue inconsistency resolved: the Task 20 moderation table lists Brian Otieno's byline team as *Curriculum & Product* while the Task 19 roster places him in *SOC — Detection & Response*. Both values are kept verbatim — `content_items.author_team` exists as its own column precisely so an editorial byline team can differ from the roster team — and `contracts-b.test.ts` asserts the id/name/initials match while documenting that the byline team is editorial.

---

## Deliberate deviations from the catalogue (all documented here, none silent)

1. **`@types/node`** added as a devDependency to every workspace (+ `packages/config`). `@vunvault/config/tsconfig.node.json` is specified with `types: ["node"]`, and Task 5's token test reads `tokens.css` with `node:fs`; without it `pnpm typecheck` fails, which the DoD forbids. Type-only, zero runtime impact.
2. **`react` / `react-dom` (catalog) + `@types/react` / `@types/react-dom`** added to `packages/ui` as peer + devDependencies. Tasks 8–13 are React components tested with Testing Library; React is not resolvable otherwise. `packages/ui` already uses `tsconfig.react-lib.json` and `eslint.next.mjs`, so this matches the workspace's declared nature.
3. **`@vunvault/config: "workspace:*"`** added to the root devDependencies — required for the root `eslint.config.mjs` / `prettier.config.mjs` re-exports to resolve under pnpm's strict `node_modules` layout.
4. **`packages/lib/src/core.test.ts`** (one extra test file) covers `cn` and `assertNever`, which Task 6's DoD requires ("every exported function covered by at least one test") but whose test files are not in the Deliverables list.
5. **`packages/ui/src/tokens.test.ts`** was updated in Task 13 so its `index.css` import-order assertion expects the sixth (`../components/preloader.css`) import that Task 13 mandates.
6. **`tsconfig.base.json` carries `"include": ["package.json"]`** so `tsc -p tsconfig.base.json --showConfig` (Task 2 DoD) prints the resolved config and exits 0 instead of failing with TS18003 "No inputs were found". Workspaces override `include` with `["src"]`, so nothing else is affected.
7. **`citext` and `bytea` column helpers** were added to `packages/db/src/schema/_columns.ts` (Task 14's file) because `drizzle-orm/pg-core` 0.45 ships neither, and Tasks 15/18 need them. The six helpers specified in Task 14 are unchanged.
8. **`react/react-in-jsx-scope` and `react/jsx-uses-react` are switched off** in `eslint.next.mjs` (every workspace compiles with the automatic JSX runtime), and `@next/next/no-html-link-for-pages` is disabled only in workspaces without an `app/`/`pages/` directory so library packages lint without plugin warnings. All other `@next/next/recommended`, jsx-a11y and react-hooks rules stay on.
9. **`aria-modal="true"` is set explicitly on `DialogContent`** — Radix Dialog 1.x sets `role="dialog"` but not `aria-modal`, which the design rules require.
10. **Toast roles** — Radix Toast hard-codes `role="status"` on its off-screen announcer, so the visible toast carries `role="alert"` (crit/warn) or `role="status"` (ok/info) itself, satisfying the Task 11 DoD.
11. **`*.tsbuildinfo` added to `.gitignore`** — `tsconfig.next.json` is specified with `incremental: true`, which emits that file in `apps/web`.
12. **`ROLE_DESCRIPTIONS` is `Partial<Record<UserRole, string>>`** because the catalogue specifies descriptions for six roles only; inventing a `client` description would violate "do not invent copy".

## Known sandbox caveats

* `pnpm install` / `pnpm <script>` must run on Node 22 (`.nvmrc`); the pre-installed Node 20 trips `engine-strict`.
* `turbo run` is invoked with `--concurrency=1` in this sandbox (1 GB RAM / 2 cores) — parallel `tsc` processes get OOM-killed. On a normal machine the plain `pnpm typecheck` works as specified.
* `turbo` warns `no output files found for task …#test` because `turbo.json` (as specified) declares `outputs: ["coverage/**"]` while Vitest is not run with `--coverage`. Warnings only; all tasks exit 0.
* The repo is not a git checkout here, so `husky` no-ops during `prepare` (`.git can't be found`) — hooks are in place and will activate on `pnpm install` inside a real clone.

---

## Task 27 — Credentials & MFA self-service (password, TOTP, WebAuthn, recovery codes, posture)
Files created: apps/api/src/routes/v1/account-security/{index,service,repo,webauthn,recovery-codes,password-policy,posture}.ts, apps/api/src/routes/v1/account-security/{account-security,recovery-codes}.test.ts
Files modified: apps/api/src/config/env.ts (WEBAUTHN_RP_ID, WEBAUTHN_RP_NAME), apps/api/src/routes/v1/auth/{index,mfa-registry}.ts (real webauthn + recovery verifiers, POST /auth/mfa/recovery, POST /auth/mfa/webauthn/options), apps/api/src/routes/v1/index.ts, apps/api/package.json, TEST_ENV literals in existing api test files
Dependencies added: @simplewebauthn/server ^13
Report: Task 27 complete. 31 account-security tests; 201 api tests green at completion.

## Task 28 — Account settings & avatar (R2 presigned upload)
Files created: apps/api/src/routes/v1/account-settings/{index,service,repo}.ts, apps/api/src/lib/object-storage.ts, apps/api/src/routes/v1/account-settings/account-settings.test.ts
Files modified: apps/api/src/lib/secrets/provider.ts (R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY), apps/api/src/config/env.ts (R2_ACCOUNT_ID, R2_BUCKET, R2_PUBLIC_BASE_URL), apps/api/src/plugins/providers.ts (app.storage), apps/api/src/types/fastify.d.ts, apps/api/src/routes/v1/index.ts, apps/api/package.json, TEST_ENV literals in existing api test files
Dependencies added: @aws-sdk/client-s3 ^3.726.0, @aws-sdk/s3-request-presigner ^3.726.0
Report: Task 28 complete. 13 tests; 214 api tests green at completion.

## Task 29 — Notification preferences, device sessions, deactivation request
Files created: apps/api/src/routes/v1/account-sessions/{index,service,repo}.ts, apps/api/src/lib/notify.ts, apps/api/src/lib/notify.test.ts, apps/api/src/routes/v1/account-sessions/account-sessions.test.ts
Files modified: apps/api/src/plugins/providers.ts (app.notify), apps/api/src/types/fastify.d.ts, apps/api/src/routes/v1/index.ts
Dependencies added: none
Report: Task 29 complete. 24 tests; 238 api tests green at completion.

## Task 30 — Client intake: profile, onboarding, pen-test requests
Files created: apps/api/src/routes/v1/client/{index,service,repo}.ts, apps/api/src/lib/secret-hash.ts, apps/api/src/lib/secret-hash.test.ts, apps/api/src/routes/v1/client/client.test.ts
Files modified: apps/api/src/routes/v1/index.ts
Dependencies added: none
Report: Task 30 complete. 25 tests (8 secret-hash + 17 client).

## Task 31 — Staff users admin: roster, summary, invitations, acceptance, account actions
Files created: apps/api/src/routes/v1/users/{index,invitations-public,service,repo,tokens}.ts, apps/api/src/routes/v1/users/{users,tokens}.test.ts
Files modified: packages/contracts/src/users.ts (InvitationPreview, AcceptInvitationBody), packages/contracts/src/routes-a.ts (GET/POST /api/v1/invitations/:token[/accept]), apps/api/src/routes/v1/index.ts
Dependencies added: none
Report: Task 31 complete. 42 tests (35 users + 7 tokens); 298 api tests green at completion.

## Task 32 — Billing foundation: provider clients, invoice issuance (ledger), subscription, payment method, invoices, PDF/CSV
Files created:
- apps/api/src/billing/ledger.ts (LedgerService, LEDGER_RECIPES, balance/positivity guards, money rules)
- apps/api/src/billing/invoice-issuer.ts (InvoiceIssuer.issue, revenueKindFor)
- apps/api/src/billing/invoice-number.ts (nextInvoiceNumber, VV-INV-<year>-<0000>)
- apps/api/src/billing/csv.ts (formula-injection-safe CSV writer)
- apps/api/src/billing/providers/{stripe,paystack,index}.ts (fetch-based REST clients, webhook HMAC verification, app.payments plugin)
- apps/api/src/routes/v1/billing/{index,service,repo}.ts
- apps/api/src/billing/billing.test.ts (27 tests)
- apps/api/src/routes/v1/billing/billing.test.ts (14 tests)
- packages/db/sql/0032_invoice_numbers.sql (billing.invoice_counters + billing.next_invoice_counter())
Files modified: apps/api/src/routes/v1/index.ts (one register line), apps/api/src/types/fastify.d.ts (app.payments)
Dependencies added: none (global fetch + node:crypto only; no Stripe/Paystack SDK)
Report: Task 32 complete. 41 new tests; 339 api tests green; repo-wide turbo typecheck/lint/test = 29/29.
