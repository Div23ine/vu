# VUNVAULT

pnpm + Turborepo monorepo for the VUNVAULT security operations platform.

## Workspace map

- `apps/web` — `web` — Next.js 15 surfaces (marketing, auth, portal, admin)
- `apps/api` — `api` — Fastify 5 API (Drizzle + Supabase Postgres)
- `apps/scan-worker` · `apps/broadcast-worker` · `apps/maintenance-worker` — background workers
- `packages/ui` — `@vunvault/ui` — design tokens and React primitives
- `packages/lib` — `@vunvault/lib` — helpers, API client, query keys
- `packages/db` — `@vunvault/db` — Drizzle schema, enums, migration runner
- `packages/contracts` — `@vunvault/contracts` — Zod schemas, permissions, fixtures
- `packages/config` — `@vunvault/config` — shared TypeScript / ESLint / Prettier configs

## Commands

`pnpm install` · `pnpm dev` · `pnpm typecheck` · `pnpm lint` · `pnpm test`
