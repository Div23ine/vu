/**
 * `(authed)/portal` — the client portal: `/portal` (scans), `/portal/billing`,
 * `/portal/security` (Password Manager), `/portal/profile`, `/portal/advisories`,
 * `/portal/studio`, `/portal/academy`, `/portal/scanner`.
 *
 * Pass-through for now. Task 45 fills it with the portal header, mobile drawer,
 * footer and the Request PenTest dialog.
 *
 * The release lock is enforced by the API, not here: a scan the review gate has not
 * released is not returned to this app at all (Task 35's `clientVisibleWhere`).
 */
export default function PortalLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
