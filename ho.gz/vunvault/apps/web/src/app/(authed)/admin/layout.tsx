/**
 * `(authed)/admin` — the Command Center: `/admin`, `/admin/scan-queue`,
 * `/admin/zero-day`, `/admin/users`, `/admin/content`, `/admin/audit`,
 * `/admin/profile`.
 *
 * Pass-through for now. Task 46 fills it with the Command Center header, the
 * permission-filtered navigation, the mobile drawer, the footer and the staff guard.
 *
 * The guard in the middleware is the first line only: every admin API route also
 * requires a staff role AND a second factor (AAL2), so a forged cookie here reaches
 * nothing.
 */
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
