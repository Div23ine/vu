/**
 * TEMPORARY placeholder for `/`.
 *
 * Task 52 deletes this file when the assembled marketing home page lands under the
 * `(marketing)` route group. It exists so that the skeleton is runnable and so the
 * route map has a `/` from the first commit — a Next app with no page at its root
 * answers 404 for `/`, which makes "does the skeleton work" impossible to check.
 */
export default function PlaceholderHome() {
  return (
    <main>
      <h1>VUNVAULT</h1>
    </main>
  );
}
