/**
 * `(auth)` — the unauthenticated flows: `/login`, `/signup`, `/accept-invite`,
 * `/forgot-password`, `/reset-password`, `/newsletter/confirm`.
 *
 * Pass-through for now. Tasks 59–63 build the pages; the edge middleware (Task 43)
 * is what keeps a signed-in visitor away from them.
 */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
