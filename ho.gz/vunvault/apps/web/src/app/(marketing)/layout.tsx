/**
 * `(marketing)` — the public site: `/`, `/about`, `/services`, `/products`, `/blog`,
 * `/blog/[slug]`, `/contact`, `/academy`.
 *
 * Pass-through for now. Task 44 fills it with the marketing header, the mobile
 * drawer, the auth-aware navigation and the footer variants, and gates the whole
 * group behind the preloader.
 */
export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
