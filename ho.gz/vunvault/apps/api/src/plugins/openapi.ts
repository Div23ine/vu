import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import fp from 'fastify-plugin';
import { jsonSchemaTransform } from 'fastify-type-provider-zod';
import type { FastifyPluginAsync } from 'fastify';
import type { Env } from '../config/env';

export interface OpenApiOptions {
  env: Env;
}

/**
 * OpenAPI 3.1 generation from the Zod schemas themselves — the document cannot
 * drift from the validation that actually runs.
 *
 * Two security schemes describe how the API is called: the HttpOnly session
 * cookie (`vv_at`) and the double-submit CSRF header. The JSON document is always
 * served; the interactive UI is not exposed in production.
 */
const openApi: FastifyPluginAsync<OpenApiOptions> = async (app, options) => {
  await app.register(swagger, {
    openapi: {
      openapi: '3.1.0',
      info: { title: 'VUNVAULT API', version: '1.0.0' },
      servers: [{ url: options.env.API_PUBLIC_URL }],
      components: {
        securitySchemes: {
          cookieAuth: { type: 'apiKey', in: 'cookie', name: 'vv_at' },
          csrf: { type: 'apiKey', in: 'header', name: 'x-csrf-token' },
        },
      },
    },
    transform: jsonSchemaTransform,
  });

  if (options.env.NODE_ENV !== 'production') {
    await app.register(swaggerUi, { routePrefix: '/docs' });
  }

  app.get(
    '/openapi.json',
    { schema: { hide: true }, config: { hidden: true, rateLimit: false } },
    async () => app.swagger(),
  );
};

export default fp(openApi, { name: 'openapi' });
