import type { RouteDoc } from './routes-a';
import type { Permission } from './permissions';

/**
 * Route documentation for the marketing backend addendum (Task 40c): the public
 * content feed and article route, the product catalogue and purchase, licence
 * entitlements with presigned downloads, and the double-opt-in newsletter.
 *
 * A contract, not an implementation. Layer L4 registers these on Fastify; the
 * conformance suite in `apps/api` compares this list against the live route table
 * and fails on drift.
 *
 * `permission` is what the API checks. `undefined` means public — and every public
 * route here is either a read of published data or a form protected by the
 * `public_form` rate-limit policy.
 */

export interface RouteDocD extends RouteDoc {
  permission?: Permission;
}

export const ROUTES_D: RouteDocD[] = [
  // --- public content -------------------------------------------------------
  {
    method: 'GET',
    path: '/api/v1/content',
    query: 'PublicContentQuery',
    response: 'paginated(PublicContentItem)',
    successStatus: 200,
    notes: 'Published items only; `Cache-Control: public, max-age=60`.',
  },
  {
    method: 'GET',
    path: '/api/v1/content/:slug',
    response: 'PublicContentDetail',
    successStatus: 200,
    errors: [{ status: 404, code: 'not_found' }],
    notes: 'Matches a published item whose `slug_path` ends in `/<slug>`.',
  },

  // --- product catalogue ----------------------------------------------------
  {
    method: 'GET',
    path: '/api/v1/products',
    response: 'paginated(ProductView)',
    successStatus: 200,
    notes: 'Active products only, ordered by `sort_order`; cacheable 300 s.',
  },
  {
    method: 'GET',
    path: '/api/v1/products/:slug',
    response: 'ProductView',
    successStatus: 200,
    errors: [{ status: 404, code: 'not_found' }],
  },
  {
    method: 'POST',
    path: '/api/v1/products/:id/purchase',
    request: 'PurchaseBody',
    response: 'PurchaseResponse',
    successStatus: 201,
    permission: 'billing:manage',
    errors: [
      { status: 403, code: 'no_org' },
      { status: 404, code: 'not_found' },
    ],
    notes:
      'Issues (or reuses) a pending USD invoice. Payment then runs through ' +
      '`POST /billing/fx-quotes` and `POST /billing/checkout`.',
  },

  // --- entitlements ---------------------------------------------------------
  {
    method: 'GET',
    path: '/api/v1/entitlements',
    response: 'paginated(EntitlementView)',
    successStatus: 200,
    notes: 'Scoped to the caller’s organisation.',
  },
  {
    method: 'POST',
    path: '/api/v1/entitlements/:id/download-url',
    response: 'DownloadUrlResponse',
    successStatus: 200,
    errors: [
      { status: 404, code: 'not_found' },
      { status: 409, code: 'not_available' },
    ],
    notes: 'Presigned GET, 300 s, `Content-Disposition: attachment`. Own org only.',
  },

  // --- newsletter -----------------------------------------------------------
  {
    method: 'POST',
    path: '/api/v1/newsletter',
    request: 'NewsletterSubscribeBody',
    successStatus: 202,
    errors: [
      { status: 400, code: 'validation_failed' },
      { status: 429, code: 'rate_limited' },
    ],
    notes:
      'Always 202: whether an address is already subscribed is not public ' +
      'information. Double opt-in — the token is emailed, never returned.',
  },
  {
    method: 'POST',
    path: '/api/v1/newsletter/confirm',
    request: 'NewsletterTokenBody',
    successStatus: 204,
    errors: [{ status: 404, code: 'not_found' }],
  },
  {
    method: 'POST',
    path: '/api/v1/newsletter/unsubscribe',
    request: 'NewsletterTokenBody',
    successStatus: 204,
    errors: [{ status: 404, code: 'not_found' }],
  },
];
