import { describe, expect, it } from 'vitest';

describe('vitest configuration', () => {
  it('loads this workspace config and runs a test', () => {
    expect(1).toBe(1);
  });
});
