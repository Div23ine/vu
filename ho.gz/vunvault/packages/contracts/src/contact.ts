import { z } from 'zod';
import { Uuid } from './common';
import { ContactCategorySchema } from './enums';
import type { ContactCategory } from './enums';

/**
 * Public contact intake and cookie consent.
 *
 * Both are unauthenticated, so both are rate limited at the API and store a
 * hashed source address rather than a raw IP. Consent is append-only: a change of
 * mind is a new record, never an edit.
 */

export const CONSENT_REQUIRED_MESSAGE = 'Consent is required';

export const ContactBody = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  organization: z.string().optional(),
  category: ContactCategorySchema,
  subject: z.string().min(3),
  message: z.string().min(10).max(5000),
  /** The checkbox is mandatory; anything other than `true` is rejected. */
  consent: z.literal(true, {
    errorMap: () => ({ message: CONSENT_REQUIRED_MESSAGE }),
  }),
});
export type ContactBody = z.infer<typeof ContactBody>;

/** `{ data: { id } }` — the only thing a contact submission reveals. */
export const ContactCreated = z.object({
  data: z.object({ id: Uuid }),
});
export type ContactCreated = z.infer<typeof ContactCreated>;

export const ContactCategories = z.object({
  /** Cannot be declined — the platform does not work without it. */
  strictlyNecessary: z.literal(true),
  analytics: z.boolean(),
  marketing: z.boolean(),
  functional: z.boolean(),
});
export type ContactCategories = z.infer<typeof ContactCategories>;

export const ConsentBody = z.object({
  categories: ContactCategories,
  policyVersion: z.string().min(1),
});
export type ConsentBody = z.infer<typeof ConsentBody>;

/** The two states the consent banner can post without a custom selection. */
export const CONSENT_ACCEPT_ALL = {
  strictlyNecessary: true,
  analytics: true,
  marketing: true,
  functional: true,
} as const satisfies ContactCategories;

export const CONSENT_ESSENTIAL_ONLY = {
  strictlyNecessary: true,
  analytics: false,
  marketing: false,
  functional: false,
} as const satisfies ContactCategories;

export const CONTACT_CATEGORY_LABELS: Record<ContactCategory, string> = {
  penetration_testing_request: 'Penetration Testing Request',
  vulnerability_report: 'Vulnerability / Bug Report',
  journalist_blogger_profile_request: 'Journalist / Blogger Profile Request',
  whistleblower_tip: 'Whistleblower Tip',
  general_support: 'General Support',
};
