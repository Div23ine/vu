# Part 3 run — progress tracker (Tasks 40b → 65)

Order required by the catalogue: 40 → **40b → 40c → 40d → 40e** → 41 (done) → 42 → 43 → 44 → 45 → 46 → 47 … 65.

| Task | Layer | Title | Status |
|---|---|---|---|
| 40b | L4 | Marketing backend addendum A: products, entitlements, newsletter, richer public content (schema + contracts) | in progress |
| 40c | L4 | Marketing backend addendum B: public content detail, product catalogue + purchase + entitlements, newsletter (routes) | pending |
| 40d | L4 | Auth addendum A: signup with email-OTP verification, forgot / reset password | pending |
| 40e | L4 | Auth addendum B: OAuth sign-in (Google, GitHub, Microsoft) via Supabase PKCE | pending |
| 41 | L5 | Next.js 15 app skeleton | **complete** (see vunvault-task-report-part3-task41.md) |
| 42 | L5 | Client runtime: providers, API bootstrap, session store, MSW mock layer | pending |
| 43 | L5 | Edge middleware (nonce CSP, route guards), permission helpers, server session, error pages | pending |
| 44 | L5 | Marketing layout: header, mobile drawer, auth-aware nav, footer variants, preloader gate | pending |
| 45 | L5 | Client portal layout + Request PenTest dialog | pending |
| 46 | L5 | Admin layout: Command Center header, permission-filtered nav, staff guard | pending |
| 47–52 | L6 | Home page A–E + Free Scanner | pending |
| 53/53b | L6 | About page A/B | pending |
| 54/54b | L6 | Services page A/B | pending |
| 55/55b | L6 | Products page A/B | pending |
| 56 | L6 | Blog list + detail + newsletter | pending |
| 57 | L6 | Contact page | pending |
| 58 | L6 | Cookie consent banner | pending |
| 59 | L7 | Login page | pending |
| 60 | L7 | MFA challenge dialog | pending |
| 61 | L7 | Signup page A | pending |
| 62 | L7 | Signup page B | pending |
| 63 | L7 | Accept-invite, forgot/reset password, newsletter-confirm | pending |
| 64 | L7 | Client onboarding wizard A | pending |
| 65 | L7 | Client onboarding wizard B | pending |

## Environment notes (this sandbox)
- Node 22 + pnpm 9.15.0 must be reinstalled to `/tmp/node22` each session: `npm i node@22 && npm i -g pnpm@9.15.0` with `PATH=/tmp/node22/node_modules/node/bin:$PATH`.
- `apps/api` typecheck needs `NODE_OPTIONS=--max-old-space-size=1200..1536` (1 GB sandbox).
- `turbo run <task> --concurrency=1` to avoid OOM.
- Baseline before this run: repo-wide 10/10 typecheck, 10/10 lint, 9/9 test tasks, 1170 tests.

## Consequential edits outside deliverable lists (disclose in each report)
- (Task 40) `apps/api/src/plugins/infra.test.ts` — one `SECRET_NAMES` list entry.
- (Task 41) `packages/ui/src/components/*.tsx` ×12 `'use client'`; `apps/web/tsconfig.json` (Next's mandatory rewrite); `apps/web/eslint.config.mjs`; `.gitignore`.
