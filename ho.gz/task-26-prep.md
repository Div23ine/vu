# Task 26 — prep sheet (VUNVAULT monorepo)

**Task:** L4 · Auth routes: signup, login, MFA challenge, refresh, logout, session
**Prerequisites per catalogue:** Task 19 (contracts), Task 20c (account schema), Task 23 (security plugins), Task 24 (auth plugin), Task 25 (audit chain).
**Status:** ⏳ blocked on repo handover — workspace currently holds only `uploads/vunvault-task-catalogue-part-2.md`.
**Verification agreed:** install deps and actually run `pnpm --filter api typecheck`, `lint`, `test`.

---

## 1. How to hand over the repo

Any of these works in this sandbox:

| Method | Notes |
|---|---|
| Upload `vunvault.tar.gz` (or `.zip`) | Preferred. Exclude `node_modules`, `dist`, `.next`, `.turbo`. `tar` and `python3 zipfile` are both available, so `.zip` is fine too. |
| `git clone <url>` | Network + git 2.39 work (npm registry reachable). If private, give an https URL with a token, or push a bundle: `git bundle create vunvault.bundle --all`. Note: `.git/config` and `.git/credentials` are excluded from workspace snapshots. |
| Paste the key files | Minimum viable set is listed in §4. |

Please include the whole monorepo if you can — I will diff my changes against it and report only the 12 Task-26 files as created/modified.

## 2. Deliverables (exactly these 12 — nothing else may change)

| # | Path | Kind |
|---|---|---|
| 1 | `apps/api/src/routes/v1/auth/index.ts` | new — route plugin |
| 2 | `apps/api/src/routes/v1/auth/service.ts` | new — `AuthService` |
| 3 | `apps/api/src/routes/v1/auth/repo.ts` | new — profiles, organizations, `login_attempts`, `user_sessions` |
| 4 | `apps/api/src/routes/v1/auth/challenge.ts` | new — Redis MFA-challenge store, AES-256-GCM payload |
| 5 | `apps/api/src/routes/v1/auth/mfa-registry.ts` | new — `MfaVerifierRegistry` (`totp`, `email_otp`, `webauthn`, `recovery`) |
| 6 | `apps/api/src/routes/v1/auth/device.ts` | new — device label + geo parsing |
| 7 | `apps/api/src/lib/breach.ts` | new — `BreachCheck` (HIBP k-anonymity) |
| 8 | `packages/db/sql/0026_client_code.sql` | new — sequence + `next_client_code()` |
| 9 | `apps/api/src/routes/v1/index.ts` | **modify** — add exactly one `app.register(authRoutes)` line |
| 10 | `apps/api/src/routes/v1/auth/auth.test.ts` | new — tests |
| 11 | `apps/api/src/routes/v1/auth/device.test.ts` | new — parser tests |
| 12 | `apps/api/src/types/fastify.d.ts` | **modify** — add `app.mfaVerifiers` |

Dependencies allowed: **none** (`node:crypto` + global `fetch` only).

## 3. Behaviour spec (checklist while implementing)

### Signup — `POST /api/v1/auth/signup`, public, policy `public_form`
- [ ] Validate `SignupBody`; password ≥ 12 with upper/lower/digit/symbol.
- [ ] `BreachCheck.isBreached`: SHA-1 → first 5 hex to `https://api.pwnedpasswords.com/range/<prefix>` with `Add-Padding: true`, compare suffix locally; 3 s timeout; timeout/5xx ⇒ **fail open** + `log.warn`. Breached ⇒ `422 { error: "breached_password" }`.
- [ ] `profiles.email` (citext) exists ⇒ `409 { error: "email_taken" }`.
- [ ] `supabase.createUser({ email, password, emailConfirm: true, userMetadata: { fullName } })` + `// DECISION(v1)` comment (no mailbox verification at signup; onboarding step 1 re-types the email).
- [ ] ONE transaction: insert `organizations` (`name` = description or full name for `individual`, `client_code` = `SELECT next_client_code()`, `country`) + `profiles` (`role: "client"`, `account_type`, `phone`, `country`, `full_name`, `first_name`/`last_name` split on first space).
- [ ] `signInWithPassword` → `setSessionCookies` (remember = false) → insert `user_sessions`.
- [ ] Audit `ACCOUNT_REGISTERED` (actor = new user, ip). Respond `201 { data: SessionUser }`.

### `0026_client_code.sql` (verbatim)
```sql
CREATE SEQUENCE IF NOT EXISTS client_code_seq START 48211;
CREATE FUNCTION next_client_code() RETURNS text AS $$ SELECT 'VV-CL-' || lpad(nextval('client_code_seq')::text, 5, '0') $$ LANGUAGE sql;
```
Codes look like `VV-CL-48210`. **Do not apply the migration.**

### Login — `POST /api/v1/auth/login`, public, policy `login`
- [ ] Lockout: failed `login_attempts` for `sha256(lower(email))` in last 15 min ≥ 5, **or** for `ip` ≥ 20 ⇒ `429 { error: "rate_limited" }` + `Retry-After: 900` + `auditFailure` `AUTH_RATE_LIMIT` (actor label `system`, subject = email, message `"<n> failed attempts in 15 min from <ip> targeting <email> · source IP temporarily blocked for 15 min"`).
- [ ] `signInWithPassword`; wrong password / unknown email / suspended / dormant / soft-deleted ⇒ identical `401 { error: "invalid_credentials" }` with identical timing (always one dummy hash comparison); record `login_attempts(succeeded=false, reason)`; `auditFailure` `AUTH_FAILURE` (actor label `external` for unknown email, else the user label).
- [ ] No-MFA success (`mfaRequired === false`, no TOTP factor, no `webauthn_credentials`): `setSessionCookies` (remember ⇒ `vv_rt` 30 days), insert `user_sessions` (device label, ip, geo), set `last_active_at`, record attempt, audit `AUTH_SUCCESS`, `200 { data: { user, mfaRequired: false, mfaMethods: [] } }`.
- [ ] MFA-available success: do **not** set `vv_at`/`vv_rt`. Random 32-byte base64url handle → Redis `mfa:<handle>` TTL 300 s `{ userId, email, remember, attempts: 0, methods, sessionEnc }`; `sessionEnc` = aal1 Supabase session AES-256-GCM encrypted, key = HKDF-SHA256(`SUPABASE_SERVICE_ROLE_KEY`, info `"vv-mfa-challenge"`). Cookie `vv_mfa` 300 s. `200 { data: { user: null, mfaRequired: true, mfaMethods: [...] } }`. `email_otp` offered only to `STAFF_ROLES`.

### MFA verify — `POST /api/v1/auth/mfa/verify`, public, needs cookie `vv_mfa`
- [ ] Missing challenge ⇒ `410 { error: "challenge_expired" }`.
- [ ] Increment `attempts`; at 5 failures delete challenge + `auditFailure` `AUTH_MFA_FAILURE` + `401 mfa_failed`.
- [ ] Delegate via `MfaVerifierRegistry`:
  - `totp`: decrypt aal1 session → `supabase.mfa.challengeAndVerify(accessToken, factorId, code)` → aal2 session.
  - `email_otp`: constant-time compare `sha256(code)` with Redis `emailotp:<userId>`; on success reuse aal1 session and write `mfa_method = 'email_otp'` on the `user_sessions` row.
  - `webauthn`, `recovery`: registry returns `501 { error: "not_implemented" }` until Task 27 registers real verifiers.
- [ ] Success: delete challenge, clear `vv_mfa`, set session cookies, insert `user_sessions` with `mfa_method`, audit `AUTH_SUCCESS` with `details: { mfa: <method> }`, `200 { data: SessionUser }`.

### Email OTP send — `POST /api/v1/auth/mfa/email-otp`, needs `vv_mfa`, staff only
- [ ] 6-digit code, store `sha256` in Redis `emailotp:<userId>` TTL 600 s, max 1 send / 60 s, send via `app.email` (subject `"Your VUNVAULT sign-in code"`, body says it expires in 10 minutes) ⇒ `202 {}`. `410` / `429` paths.

### Refresh / Logout / Session
- [ ] `POST /refresh` (needs `vv_rt`): `supabase.refresh`, rotate both cookies, update `user_sessions.last_seen_at` ⇒ `204`. Invalid ⇒ clear cookies, `401 unauthorized`.
- [ ] `POST /logout` (authenticated): `supabase.signOut(at, "local")`, set `user_sessions.revoked_at`, clear all cookies, audit `AUTH_LOGOUT`, `204`.
- [ ] `GET /session` (authenticated): `200 { data: SessionUser }`, `mfaEnrolled` = verified TOTP factor OR a WebAuthn credential exists.

### `device.ts`
- [ ] `deviceLabel(userAgent)` → `"<Device> · <Browser>"` using coarse labels only: `Mac · Safari`, `Windows PC · Chrome`, `iPhone · Safari`, `Android · Chrome`, `Linux · Firefox`, fallback `Unknown device · Unknown browser`.
- [ ] Geo from Cloudflare headers `cf-ipcity`, `cf-ipcountry` when present.

### Hard rules
- Fastify 5, `FastifyPluginAsync`, `withTypeProvider<ZodTypeProvider>()`, Zod schemas from `@vunvault/contracts`.
- `routes → service → repo`; repos take `Db | Tx` and return plain objects; route files contain **no** Drizzle calls.
- Public routes omit `preHandler`; every state-changing route wrapped in `audited(spec, handler)` using `ctx.tx`.
- Errors via `HttpError`; envelope `{ error, message?, details? }`; success `{ data }` / `{ data, total }`.
- Tests: Vitest + `app.inject()`, in-memory fake repos/providers, **no** live DB/Redis/network.
- Forbidden: Express, Prisma, Joi, `localStorage`, `sessionStorage`, hard-coded secrets, tokens in response bodies.
- Failure responses never echo the word `password` and never contain stack traces.

## 4. Symbols I must confirm in the repo before writing code

From **Task 19 / 20d** (`packages/contracts`): `SignupBody`, `LoginBody`, `MfaVerifyBody`, `SessionUser`, `UserRole`, `Permission`, `ROLE_PERMISSIONS`, `MfaMethod`, `JwtClaims`, audit-event unions, and whatever the auth route response schemas are called.
From **Task 20c** (`packages/db`): `profiles` (incl. `account_status`, `deleted_at`, `mfa_required?`, `last_active_at`, `first_name`, `last_name`, `require_2fa`), `organizations`, `user_sessions`, `login_attempts`, `webauthn_credentials`, `mfa_method` enum, `Db`/`Tx` types and the `withTx` helper name.
From **Task 21**: `HttpError`, `buildApp`, `env`/`Env`, `app.env`, error-handler envelope.
From **Task 22**: `app.secrets` (get API), `app.db`, `app.redis` (client shape + fake), `app.email` (`send({to,subject,text|html})`?), `app.queues`.
From **Task 23**: `COOKIE_NAMES`, `cookieOptions(name,{remember})`, `RATE_POLICIES` names, `config.rateLimitPolicy`, `config.csrf`, `req.rawBody`.
From **Task 24**: `app.authenticate`, `app.requireStaff`, `app.requirePermission`, `AuthUser`, `SupabaseAdmin` + `SupabaseSession`, `setSessionCookies` / `clearSessionCookies` / `readSessionCookies`, `STAFF_ROLES`, `isStaff`, `session-registry` invalidation hook.
From **Task 25**: `app.audit.append`, `app.audited` / `audited(spec, handler)` signature, `auditFailure(app, spec, req, err)`, `AUDIT_EVENTS` keys used here (`AUTH_SUCCESS`, `AUTH_FAILURE`, `AUTH_MFA_FAILURE`, `AUTH_RATE_LIMIT`, `AUTH_LOGOUT`, `ACCOUNT_REGISTERED`), `isAudited`.

## 5. Required test assertions (`auth.test.ts`)

1. signup happy path sets `vv_at`, `vv_rt`, `vv_csrf` and writes organization + profile
2. breached password → 422
3. duplicate email → 409
4. 5 bad logins → 6th is 429 **and** an `AUTH_RATE_LIMIT` audit entry exists
5. wrong password and unknown email produce byte-identical bodies
6. MFA-enrolled login sets `vv_mfa` and NOT `vv_at`
7. TOTP verify success sets `vv_at`
8. the 5th wrong TOTP deletes the challenge
9. the Redis challenge payload contains no plaintext access token
10. logout clears cookies and revokes the session row
11. `webauthn` verify returns 501 now

Plus `device.test.ts` for the UA/geo parser.

## 6. Out of scope for Task 26

Password change, TOTP enrolment, WebAuthn, recovery codes (Task 27) · email verification links · tokens in bodies · applying the SQL migration.

## 7. Report format on completion

```
Task 26 complete. Files created: <list>. Files modified: <list>. Dependencies added: none.
```
