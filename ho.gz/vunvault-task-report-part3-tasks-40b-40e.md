# VUNVAULT — Part 3 completion report: Tasks 40b–40e (backend addenda)

Repository: `/home/user/vunvault` (restored monorepo, pnpm 9.15.0 + Turborepo, Node 22
pinned by `engines`). Verification ran on Node v22.23.3 (installed to `/tmp/node22`);
`tsc` for `apps/api` needs `NODE_OPTIONS=--max-old-space-size=1536` in this 1 GB sandbox,
and `turbo run typecheck` OOM-kills `api#typecheck` there — the api package was verified
with direct `pnpm --filter api …` runs instead, every other package via
`turbo run typecheck lint test --filter='!api' --concurrency=1`.

## Verification (after Task 40e)

| Check | Command | Result |
| --- | --- | --- |
| api typecheck | `pnpm --filter api typecheck` (heap 1536 MB) | **0 errors** |
| api lint | `pnpm --filter api lint` | **0 errors** |
| api tests | `pnpm --filter api test` | **45 files, 856 tests pass** |
| db | typecheck · lint · test | pass (139 tests, 9 files) |
| contracts | typecheck · lint · test | pass (126 tests, 5 files) |
| Rest of repo | `turbo run typecheck lint test --filter='!api'` | **26 / 26 tasks pass** |
| Stack guards | `pnpm verify` | `OK: verify-no-html` · `OK: verify-forbidden-stack` |
| Formatting | `pnpm format:check` | All files use Prettier code style |
| Conformance | `src/conformance/route-table.test.ts` | passes with all new routes |

api test growth across the run: 784 (after T40) → 797 (T40b/40c routes) → **819** (T40c
tests complete) → **840** (T40d) → **856** (T40e).

---

## Task 40b complete.
Files created: `packages/db/src/schema/store.ts`, `packages/db/sql/0040_products_seed.sql`,
`packages/contracts/src/store.ts`, `packages/contracts/src/routes-d.ts`,
`packages/contracts/fixtures/store.ts`, `packages/db/src/schema/store.test.ts`,
`packages/contracts/src/contracts-d.test.ts`
Files modified: `packages/db/src/enum-values.ts`, `packages/db/src/schema/content.ts`,
`packages/db/src/schema/billing.ts`, `packages/db/src/schema/index.ts`,
`packages/contracts/src/content.ts`, `packages/contracts/src/routes-b.ts`,
`packages/contracts/fixtures/index.ts`, `packages/contracts/src/index.ts`
Dependencies added: none

Notes: three new tables (`products`, `product_entitlements`, `newsletter_subscribers`), all
RLS-enabled; `content_items.severity` + the `(type, severity, published_at desc)` index;
`invoice_lines.product_id → products.id`; the six-product idempotent seed with verbatim
catalogue copy; `PublicContentItem` replaced (`summary` → `excerpt`, + slug/category/
severity/tags/readMinutes/image fields), `PublicContentQuery` (`q` search lives in
`PageQuery`), `PublicContentDetail`, `SEVERITY_CHIP_LABELS`; `ROUTES_D` documentation
constant; fixtures carry the six seed posts verbatim with the prototype→Studio category
mapping. The Task 20 `GET /api/v1/content` doc entry in `routes-b.ts` gained the one
required line pointing at `ROUTES_D`.

## Task 40c complete.
Files created: `apps/api/src/routes/v1/store/{index,service,repo,license-key,store.test}.ts`,
`apps/api/src/routes/v1/newsletter/{index,service,newsletter.test}.ts`,
`apps/api/src/routes/v1/content/content-public.test.ts`
Files modified: `apps/api/src/routes/v1/content/{index,service,repo}.ts`,
`apps/api/src/routes/v1/content/content.test.ts` (consequential — see below),
`apps/api/src/routes/v1/webhooks/service.ts`, `apps/api/src/audit/events.ts`,
`apps/api/src/audit/events.test.ts`, `apps/api/src/conformance/route-manifest.ts`,
`apps/api/src/conformance/route-table.test.ts`, `apps/api/src/routes/v1/index.ts`
Dependencies added: none

Notes: public content feed (ILIKE `q` over title/excerpt/summary/cve_id/tags, category/
severity/type filters, `sort=priority` = critical→low then newest with nulls last,
`Cache-Control: public, max-age=60`) and `/content/:slug` detail (404 for anything not
published-and-due). Product catalogue is public and cacheable 300 s; purchase reuses a
pending invoice inside 24 h (two clicks, one debt), issues via `InvoiceIssuer` with the
`productId` line, audits `PRODUCT_PURCHASE_STARTED`; payment stays on the Task 33 FX +
checkout rails (USD only). `EntitlementService.grantForInvoice` runs inside the webhook
transaction, is idempotent, mints Crockford-base32 `VV-XXXX-XXXX-XXXX-XXXX` keys with
unique-retry, `updates_until = granted_at + 12 months`, audits `ENTITLEMENT_GRANTED`
(system actor, key never in the chain) and emails the key. Downloads: 300 s presigned GET
with attachment disposition, cross-org attempts answer 404 (existence is not public),
409 `not_available` without an archive, audited `PRODUCT_DOWNLOADED`, rate policy
`sensitive`. Newsletter: always-`202 {}` double opt-in, SHA-256'd single token serving
confirm AND unsubscribe, daily-salted IP hash, 10-minute resend throttle, audit on
CONFIRM only (`external` actor, address never in the entry).
Consequential edit outside the deliverables list: `content/content.test.ts` asserted the
Task 20 projection's exact key set; Task 40b explicitly *replaces* that shape, so the
expectation was updated to the new 15-key projection (nothing else in the file changed).

## Task 40d complete.
Files created: `apps/api/src/routes/v1/auth/email-otp.ts`,
`apps/api/src/routes/v1/auth/password-reset.ts`,
`apps/api/src/routes/v1/auth/signup-verify.test.ts`,
`apps/api/src/routes/v1/auth/password-reset.test.ts`
Files modified: `packages/db/src/enum-values.ts`, `packages/contracts/src/permissions.ts`,
`packages/contracts/src/auth.ts`, `packages/contracts/src/routes-a.ts`,
`packages/contracts/src/contracts-a.test.ts`, `apps/api/src/lib/supabase-admin.ts`,
`apps/api/src/routes/v1/auth/{service,index,repo}.ts`,
`apps/api/src/routes/v1/auth/auth.test.ts`,
`apps/api/src/conformance/route-manifest.ts`, `docs/adr/0002-api-conventions.md`,
plus three consequential files (below)
Dependencies added: none

Notes: signup is now the verified flow. `POST /auth/signup` → `202 SignupStartResponse`,
**no cookies**: Supabase user created unconfirmed, profile `pending_verification` with
`require_2fa = true`, six-digit `crypto.randomInt` OTP into Redis under
`signup:otp:<sha256(email)>` (digest only, TTL 600 s), emailed with the exact subject;
`debug`-level code logging in `NODE_ENV=development` only. An existing
`pending_verification` signup is REPLACED (unverified Supabase user + rows deleted); an
active one is still `409 email_taken`. `verify-email` (policy `login`): constant-time
compare, five failures destroy the OTP (`401 otp_exhausted`), wrong code `401 otp_invalid`
(attempts++ without extending TTL), missing/expired `410 otp_expired`; success confirms the
mailbox, activates the profile, mints an aal1 session server-side
(`generateLink(magiclink)` → `verifyOtp(token_hash)`), sets the three cookies with
`remember=false`, writes `user_sessions`, audits `ACCOUNT_REGISTERED {stage:
"email_verified"}` — the web app then runs the Task 27 TOTP enrolment for step 3.
`resend` always `202 {}`, 30 s cooldown, rotates the code. `forgot-password` always
`202 {}` with identical body and an equalising dummy-token hash for unknown addresses;
32-byte base64url token, digest-keyed `pwreset:` record, TTL 1800 s, max three live tokens
per user (oldest evicted), nothing audited at request time. `reset-password` consumes the
token atomically (GETDEL with get+del fallback; `410 token_invalid` for used/expired/
unknown), re-validates role-aware (staff 14 / client 12) plus breach check, updates the
password at Supabase, revokes EVERY `user_sessions` row, stamps `last_password_change_at`,
sends `credentials_changed`, audits `PASSWORD_CHANGED` (actor = the user, details
`{via: "reset"}`), answers `204`; MFA is not bypassed. `SignupBody.password` now carries
the Task 26 complexity rules (shared `NewPassword`), `ResetPasswordBody` mirrors
`ChangePasswordBody`'s confirm refine ("Both entries must match exactly.").
`listStalePendingSignups(olderThan)` documents the 24 h cleanup contract for the L11
maintenance worker. The `DECISION(v1)` comments are deleted and ADR 0002 gained item 11
recording the superseding decision. `.env.example` unchanged (no new variables).
`packages/db/src/schema/_enums.ts` needed no literal edit: `accountStatusEnum` derives
from `ACCOUNT_STATUSES`, so the new value propagates automatically.
Consequential edits outside the deliverables list (interface/enum changes force them; the
suite must stay green): `packages/db/src/enum-values.test.ts` (status list + count),
`apps/api/src/plugins/auth.ts` (`unavailableSupabase()` must implement the widened
interface), `apps/api/src/routes/v1/account-security/account-security.test.ts` (its
`fakeSupabase` likewise).

## Task 40e complete.
Files created: `apps/api/src/routes/v1/auth/oauth.ts`,
`apps/api/src/routes/v1/auth/oauth-service.ts`, `apps/api/src/lib/pkce.ts`,
`apps/api/src/routes/v1/auth/oauth.test.ts`
Files modified: `apps/api/src/lib/supabase-admin.ts`,
`apps/api/src/routes/v1/auth/index.ts`, `apps/api/src/conformance/route-manifest.ts`,
`packages/contracts/src/routes-a.ts`, plus the consequential fakes (below)
Dependencies added: none

Notes: `GET /auth/oauth/:provider/start` (policy `public_form`) validates
`google|github|microsoft` (anything else 404), sanitises `next` (relative, single leading
`/`, no `\` — else `/portal`), mints 24-byte `state` + 43-char PKCE verifier, stores
`{provider, verifier, next}` under `oauth:state:<state>` for 600 s, sets HttpOnly/Lax
`vv_oauth` (Path `/api/v1/auth`, 600 s) and 302s to the Supabase authorize URL with
`code_challenge_method=s256` and `redirect_to=<API_PUBLIC_URL>/api/v1/auth/oauth/callback`;
`microsoft` maps to Supabase `azure`. `GET /auth/oauth/callback` requires query state ==
cookie state == a live Redis record consumed atomically (else `/login?error=oauth_state`),
maps a provider `error` to `oauth_denied`, and exchanges code+verifier for a real aal1
session. Refusals: unverified mailbox → `oauth_email_unverified` (and the Supabase user
this attempt created is deleted); staff profile → session destroyed globally,
`oauth_not_allowed`, `AUTH_FAILURE {provider, reason: "staff_oauth_blocked"}`; email owned
by a different profile id → `oauth_email_in_use` (never auto-linked). First sign-in creates
a CLIENT account (org from `next_client_code()`, `account_status 'active'`,
`require_2fa false`, name from provider metadata or the email local-part) audited as
`ACCOUNT_REGISTERED {provider}`. With a verified TOTP factor or WebAuthn key the login
flow's challenge is created verbatim (`vv_mfa`, `/login?mfa=1&next=…`, no `vv_at`);
otherwise cookies + `user_sessions` + `AUTH_SUCCESS {provider}` and a redirect to `next`,
or `/onboarding` while `onboarding_profiles.completed_at` is missing. `vv_oauth` is always
cleared; no token appears in any URL, body or redirect target.
Implementation note: supabase-js 2.117's `exchangeCodeForSession` reads the verifier from
the SDK's own storage, so the wrapper posts `grant_type=pkce` to the GoTrue token endpoint
directly (same request the SDK sends; same raw-fetch pattern as the existing
`deleteSession`). The onboarding lookup lives in a one-query `SqlOnboardingRepo` inside
`oauth-service.ts` because the auth `repo.ts` was not a 40e deliverable.
Consequential edits outside the deliverables list: `packages/contracts/src/contracts-a.test.ts`
(the ROUTES_A doc test now also exempts 302s from the response-name rule — redirects carry
no envelope) and the `SupabaseAdmin` fakes in `auth.test.ts`, `signup-verify.test.ts`,
`password-reset.test.ts`, `account-security.test.ts`, `plugins/auth.ts` (widened
interface).

---

## Decisions

1. **`/home/user/task-26-conformance-fixes.patch` was discarded, not applied.** It audited
   Task 26's pre-40d signup route; Task 40d explicitly replaces that route and contract,
   and the whole suite is green without it. Applying it now would resurrect code the
   catalogue ordered deleted (including the `DECISION(v1)` comments).
2. **40b/40c file attribution.** The previous session had already scaffolded the 40c
   route files while working 40b; files are attributed above per the catalogue's
   deliverables lists (schema + contracts → 40b, routes + route tests → 40c), which is
   also how the two report lines are split.
3. **Redirect routes are documented with `successStatus: 302` and no `response` name** —
   a 302's payload is its `Location`. The ROUTES_A doc test and the conformance
   `NO_JSON_RESPONSE` list were extended accordingly rather than inventing a body schema.
4. **Reset-time session revocation** follows the Task 27 password-change precedent:
   Supabase's admin password update revokes GoTrue's own refresh tokens, our
   `user_sessions` rows are revoked in the transaction, and the session registry's Redis
   cache expires within its 30 s TTL — the same window the authenticated change relies on.
