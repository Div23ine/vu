# VUNVAULT — Part 3 completion report: Task 41

Repository: `/home/user/vunvault` (pnpm 9.15.0 + Turborepo, Node 22 pinned by `engines`).
Verification ran on Node v22.23.3 installed to `/tmp/node22` (the sandbox ships Node 20 and
`.npmrc` sets `engine-strict=true`).

## Task 41 complete — Next.js 15 app skeleton

`apps/web` is now a runnable Next.js 15 (App Router, React 19) app wired to the shared
design system: config with security headers, Tailwind v4 through `@tailwindcss/postcss`,
self-hosted Inter, the root layout with verbatim metadata, five pass-through route-group
layouts, the temporary `/` placeholder, and Zod-validated public env.

### Verification

| Check | Command | Result |
| --- | --- | --- |
| Typecheck | `pnpm --filter web typecheck` | **0 errors** |
| Lint | `pnpm --filter web lint` | **0 errors, 0 warnings** |
| Tests | `pnpm --filter web test` | **10 passed** (`src/env.test.ts`) |
| Production build | `next build` | **succeeds** — `/` prerendered static, 103 kB first-load JS |
| Runtime smoke | `next start` + fetch `/` | **200**, `<h1>VUNVAULT</h1>`, verbatim title, `<html lang="en" class="__variable_…">`, `<body class="min-h-screen bg-paper text-ink antialiased font-sans">`, compiled CSS linked, no server-log errors |
| Security headers | response headers on `/` | HSTS `max-age=63072000; includeSubDomains; preload` · `X-Content-Type-Options: nosniff` · `Referrer-Policy: strict-origin-when-cross-origin` · `Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(self)` · `X-Frame-Options: DENY` · `Cross-Origin-Opener-Policy: same-origin-allow-popups` · **no `X-Powered-By`** · no CSP (Task 43) |
| Tailwind v4 wiring | built CSS (47,359 bytes) | contains `bg-paper`, `text-ink`, `font-sans`, `--font-inter`, `ease-vv`, `animate-vv-*`, `.vv-preloader`, the `prefers-reduced-motion` block, and Task 5's semantic tokens (`--dark-abyss`, `--sh-card`, `--grad-brand`, `--r-field`, …) |
| Token discipline | grep over new files | **zero hex literals**; `viewport.themeColor` reads `tokens.color.paper` from `@vunvault/ui` |
| Repo-wide | `turbo run typecheck / lint / test --concurrency=1` | **10 / 10 · 10 / 10 · 9 / 9 — 1170 tests** (api 784 · db 123 · ui 101 · contracts 98 · lib 54 · web 10) |
| Stack guards | `pnpm verify` | `OK: verify-no-html` · `OK: verify-forbidden-stack` |
| Formatting | `pnpm format:check` | clean |

### Files created

`apps/web/next.config.ts` · `apps/web/postcss.config.mjs` · `apps/web/.env.example` ·
`apps/web/public/brand/.gitkeep` · `apps/web/src/env.ts` · `apps/web/src/env.test.ts` ·
`apps/web/src/lib/fonts.ts` · `apps/web/src/app/globals.css` · `apps/web/src/app/layout.tsx` ·
`apps/web/src/app/page.tsx` · `apps/web/src/app/(marketing)/layout.tsx` ·
`apps/web/src/app/(auth)/layout.tsx` · `apps/web/src/app/(authed)/layout.tsx` ·
`apps/web/src/app/(authed)/portal/layout.tsx` · `apps/web/src/app/(authed)/admin/layout.tsx`

### Files modified

In the deliverables list: `apps/web/package.json` (scripts + dependencies).

Outside it — each one forced by a deliverable, none silent:

1. **`packages/ui/src/components/{button,checkbox,data-table,dialog,form,label,preloader,select,select-column,switch,toast,tooltip}.tsx`** — added a `'use client'` directive (12 files, one line + comment each).
   Task 41 requires `layout.tsx` to read `tokens.color.paper` from `@vunvault/ui`; that
   import pulls the package barrel, which re-exports `preloader.tsx` and the Radix wrappers.
   Those use `useState`/`useEffect`, and `next build` fails with *"You're importing a
   component that needs `useState` … mark the file with the `"use client"` directive"*.
   The components were built and tested under Vitest + jsdom (Tasks 8–13) and had never been
   compiled by the App Router, so this is a latent Task 8–13 gap that Task 41 is the first
   task able to hit. `@radix-ui/react-slot` ships without the directive, which is why
   `button.tsx` needs it too. All 101 `@vunvault/ui` tests still pass, and its typecheck and
   lint are clean.
2. **`apps/web/tsconfig.json`** — `next build` rewrote it and says so: `esModuleInterop: true`
   (mandatory for SWC), `include` gained `.next/types/**/*.ts`, `exclude: ["node_modules"]`.
   Reverting it would make every `next dev`/`next build` dirty a tracked file again.
   `strict: true` and `noUncheckedIndexedAccess` are inherited from the shared base and were
   not weakened.
3. **`apps/web/eslint.config.mjs`** — now spreads the shared config and adds
   `{ ignores: ['next-env.d.ts', '.next/**'] }`. `next-env.d.ts` is generated and contains a
   triple-slash reference that `@typescript-eslint/triple-slash-reference` rejects; linting a
   generated file is linting somebody else's output.
4. **`.gitignore`** — added `next-env.d.ts`, because the deliverable itself says
   "`next-env.d.ts` is generated; do not commit it (ensure it is gitignored)".
5. **`pnpm-lock.yaml`** — the permitted dependency additions, then Prettier-formatted by the
   repo's own `format` script.

### Dependencies added

Runtime: `next` (catalog `^15.0.0` → 15.5.27), `react`, `react-dom` (catalog `^19.0.0` →
19.3.0), `zod` (catalog → 3.25.76), `lucide-react` `^0.468.0` (same version `packages/ui`
already pins).
Dev: `@tailwindcss/postcss` `^4.0.0` (→ 4.3.3), `tailwindcss` (catalog `^4.0.0`),
`@types/react` / `@types/react-dom` `^19.0.2` (`@types/node` was already present).
Nothing outside the allowed list.

### Notes for the next tasks

- **Operator pre-step still outstanding:** `apps/web/public/brand/logo.svg` does not exist
  (only `.gitkeep`, as instructed — "do not create it"). `packages/ui`'s `Logo` and
  `Preloader` reference `/brand/logo.svg`, so they will 404 until the operator copies it in.
- **Route map is in place but empty.** `(marketing)`, `(auth)`, `(authed)`, `(authed)/portal`
  and `(authed)/admin` layouts are pass-throughs carrying a comment naming the task that fills
  them (44, 45, 46). `src/app/page.tsx` is the temporary `/`; Task 52 deletes it when the
  assembled home page lands under `(marketing)` — until then, adding `(marketing)/page.tsx`
  would collide with it.
- **Prerequisite ordering.** Part 3 states the order `40 → 40b → 40c → 40d → 40e → 41`, and
  Task 41 lists Task 40c as a prerequisite. Task 41 was executed first on instruction; it
  consumes none of 40c's output (it is app scaffolding only). 40b/40c are needed by Tasks 49,
  55 and 56, and 40d/40e by Tasks 59–63, so they should run before those.
- **`NEXT_PUBLIC_*` are inlined at build time.** `src/env.ts` reads them field by field
  (never `process.env` wholesale) so the module stays importable from client components, and
  it throws at import when a required origin is missing — `next build` therefore needs
  `NEXT_PUBLIC_API_URL` and `NEXT_PUBLIC_SITE_URL` set.

---

```
Task 41 complete. Files created: apps/web/next.config.ts, apps/web/postcss.config.mjs, apps/web/.env.example, apps/web/public/brand/.gitkeep, apps/web/src/env.ts, apps/web/src/env.test.ts, apps/web/src/lib/fonts.ts, apps/web/src/app/globals.css, apps/web/src/app/layout.tsx, apps/web/src/app/page.tsx, apps/web/src/app/(marketing)/layout.tsx, apps/web/src/app/(auth)/layout.tsx, apps/web/src/app/(authed)/layout.tsx, apps/web/src/app/(authed)/portal/layout.tsx, apps/web/src/app/(authed)/admin/layout.tsx. Files modified: apps/web/package.json, apps/web/tsconfig.json (Next's own mandatory rewrite), apps/web/eslint.config.mjs (ignore generated next-env.d.ts), .gitignore (next-env.d.ts), packages/ui/src/components/{button,checkbox,data-table,dialog,form,label,preloader,select,select-column,switch,toast,tooltip}.tsx ('use client'), pnpm-lock.yaml. Dependencies added: next, react, react-dom, zod, lucide-react; @tailwindcss/postcss, tailwindcss, @types/react, @types/react-dom (dev).
```
