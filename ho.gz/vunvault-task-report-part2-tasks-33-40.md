# VUNVAULT — Part 2 completion report: Tasks 33–40 (Layer L4 closeout)

Repository: `"$ARENA_WORKSPACE"/vunvault` (restored from the 2026-10-05 16:40 session snapshot;
pnpm 9.15.0 + Turborepo, Node 22 pinned by `engines`).
Verification ran on Node v22.23.3 (installed to `/tmp/node22`) because the sandbox ships
Node 20 and `.npmrc` sets `engine-strict=true`. `tsc` for `apps/api` now needs
`NODE_OPTIONS=--max-old-space-size=1536` in this 1 GB sandbox; on a normal machine the
plain `pnpm --filter api typecheck` works.

## Verification (after Task 40)

| Check | Command | Result |
| --- | --- | --- |
| Typecheck | `turbo run typecheck --concurrency=1` | **10 / 10 packages pass** |
| Lint | `turbo run lint --concurrency=1` | **10 / 10 packages pass, 0 errors** |
| Tests | `turbo run test --concurrency=1` | **9 / 9 tasks, 1160 tests** (api 784 · db 123 · contracts 98 · lib 54 · ui 101) |
| Stack guards | `pnpm verify` | `OK: verify-no-html` · `OK: verify-forbidden-stack` |
| Formatting | `pnpm format:check` | All files use Prettier code style |
| Conformance | `src/conformance/route-table.test.ts` | **12 checks pass over the whole route table** |

Test growth across the run: 339 → 393 (T33) → 427 (T34) → 481 (T35) → 599 (T36) →
655 (T37) → 719 (T38) → 755 (T39) → **784 (T40)**.

---

## Task 33 complete.
Files created: `apps/api/src/routes/v1/checkout/{index,service,repo,checkout.test}.ts`,
`apps/api/src/billing/{fx-rates,money,money.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`, `apps/api/src/config/env.ts`
Dependencies added: none
Notes: BigInt-only FX maths at 1e8 scale (both catalogue values asserted verbatim);
`fx:latest` cached 15 min with a 4 s upstream timeout and `502 fx_unavailable` on a cold
miss; quotes single-use and amount-pinned; checkout charges `outstanding_usd_cents` only.
`FX_API_URL` / `FX_QUOTE_TTL_SECONDS` are declared `.optional()` with the catalogue's
defaults applied by `resolveFxConfig()`: a Zod `.default()` would make the key required in
the inferred `Env` type and break the five existing `const TEST_ENV: Env` literals, which
are outside this task's deliverables.

## Task 34 complete.
Files created: `apps/api/src/routes/v1/webhooks/{index,service,webhooks.test}.ts`,
`apps/api/src/routes/v1/payments-admin/{index,service,repo,payments-admin.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`
Dependencies added: none
Notes: real HMAC-SHA256 (Stripe) / HMAC-SHA512 (Paystack) signatures are computed in the
tests, so verification runs rather than being mocked. Amount and currency from a provider
are compared against the stored attempt; a mismatch fails the attempt with
`amount_mismatch` and posts nothing. Event rows are stored inside the processing
transaction, so a 500 rolls the row back and the provider's retry is not swallowed as a
replay. Checkout still never posts to the ledger — proven three ways in Task 33's tests and
unchanged here.

## Task 35 complete.
Files created: `apps/api/src/routes/v1/scans/{index,service,gate,repo,visibility,authorisation,scans.test,gate.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`
Dependencies added: none
Notes: `clientVisibleWhere()` is the only source of the client release lock, and a test
scans the module sources to prove no client query hand-writes it. Gate rules are pure and
tested as a full status × action grid. Payment lock: an approval on an unpaid job commits
the decision row, the checklist and a SEV-2 `RELEASE_LOCK_VIOLATION`, then answers 409.
Release is final (`409 already_released`). `WORKER_SLOTS_TOTAL` is read by a local
`workerSlotsTotal()` helper rather than added to `config/env.ts` (same deliverable-scope
reason as Task 33).

## Task 36 complete.
Files created: `apps/api/src/routes/v1/content/{index,service,repo,state-machine,state-machine.test,content.test}.ts`,
`apps/api/src/routes/v1/studio/{index,service,markdown,slug,studio.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`
Dependencies added: none
Notes: the markdown sanitiser removes `script`/`style`/`iframe`/`object`/`embed`/`svg`/
`math` elements with their contents, strips tags and comments, and rewrites any link whose
target is not http, https, mailto or relative — including percent-encoded and
whitespace-split `javascript:`. Slugs are unique by `-2`, `-3`. Draft saves are audited at
most once a minute per item (the throttle map lives in the plugin, not the per-request
service). `DELETE /studio/drafts/:id` writes no chain entry: the catalogue defines no event
for discarding a private draft (recorded in `AUDIT_EXEMPT`).

## Task 37 complete.
Files created: `apps/api/src/routes/v1/dashboard/{index,service,repo,cache,threat-level,dashboard.test,threat-level.test}.ts`,
`apps/api/src/routes/v1/nodes/{index,service,nodes.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`
Dependencies added: none
Notes: `computeThreatLevel` implements the documented formula; the prototype's fixture
(9 unpatched critical, 37 weaponised, 62 % coverage) scores **86.6 → level 5**, not the
"Level 4 / High" the card showed. Nine GET panels cached 15 s under `dash:<name>` with
`?refresh=1` bypass; tier shares use largest-remainder rounding so they sum to exactly 100.
Node heartbeats verify Ed25519 over `nodeCode|sentAt|reqPerMin|loadPercent|clockDriftMs`,
refuse >30 s skew as `401 stale`, and answer an unknown node exactly as they answer a bad
signature. `NODE_LABEL` is read by a local helper for the same env-scope reason.

## Task 38 complete.
Files created: `apps/api/src/routes/v1/advisories/{index,service,repo,matching,nvd,validation,advisories.test,matching.test,validation.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`
Dependencies added: none
Notes: broadcast guard order is completeness → five acknowledgements + typed phrase →
`intel:broadcast` → one-per-minute. The SEV-1 entry is appended inside the transaction so
its chain height can be written to `advisory_broadcasts.audit_seq`; that is why
broadcast/rebroadcast append by hand and carry the `vv.audited` tag rather than using the
`audited()` wrapper (retract and patch-status do use the wrapper). Delivery is queued after
commit and a queue failure is logged, not thrown: the row stays `queued` for the maintenance
worker and the response is still 202.

## Task 39 complete.
Files created: `apps/api/src/routes/v1/audit/{index,service,repo,csv,sse,audit-routes.test,sse.test}.ts`
Files modified: `apps/api/src/routes/v1/index.ts`, `docs/adr/0001-audit-chain.md`
Dependencies added: none
Notes: the projection selects thirteen columns by name — `details`, `sealed_details`,
`nonce`, `signature` and `key_id` are never read. Verification is serialised behind
`audit:verify:lock` (TTL 600 s) and released in a `finally`. SSE carries `id: <seq>`,
honours `Last-Event-ID` with a 200-entry replay, heartbeats every 20 s, re-checks the
session every 30 s, drops a reader whose buffer exceeds 1 MB, releases its dedicated Redis
subscriber on close/abort/error, and caps five streams per user. Exports are counted before
a byte is written, so an over-wide filter answers `422 range_too_large` instead of
truncating.

## Task 40 complete.
Files created: `apps/api/src/routes/v1/public/{index,service,repo,turnstile,public.test}.ts`,
`apps/api/src/routes/v1/admin-badges/index.ts`,
`apps/api/src/conformance/{route-table.test,route-manifest}.ts`,
`docs/adr/0002-api-conventions.md`
Files modified: `apps/api/src/lib/secrets/provider.ts` (+`TURNSTILE_SECRET_KEY`),
`apps/api/src/routes/v1/index.ts`, `apps/api/.env.example`,
`apps/api/src/plugins/infra.test.ts` (see deviations), `docs/adr/0001-audit-chain.md` was
modified in Task 39.
Dependencies added: none
Notes: the contact form hashes the IP with a daily salt, audits the category only, marks
`journalist_blogger_profile_request` with the `[Verification]` subject prefix, and answers
`201` to a filled honeypot while doing nothing. Consent issues `vv_anon` as
`HttpOnly; Secure; SameSite=Lax; 1 year`. The conformance suite builds the full route table
with inert infrastructure and enforces auth coverage, the admin triple-guard, audit
coverage, CSRF, schemas, rate-limit policies, audit-prefix immutability, contract drift and
the forbidden stack.

---

## Deliberate deviations, all disclosed

1. **`apps/api/src/plugins/infra.test.ts` — one list entry added.** Task 40 requires
   `TURNSTILE_SECRET_KEY` in `SECRET_NAMES`; that file pins the exact list, so the two
   requirements can only both hold by updating the assertion. One line, with a comment.
2. **`apps/api/src/config/env.ts` (Task 33).** `FX_API_URL` / `FX_QUOTE_TTL_SECONDS` are
   `.optional()` with defaults applied by `resolveFxConfig()`, because `.default()` would
   break five existing `Env` literals outside the deliverables list.
3. **`WORKER_SLOTS_TOTAL` (Task 37) and `NODE_LABEL` (Task 37)** are read from
   `process.env` by exported helpers in their own modules for the same reason; both are
   now named in `.env.example` (Task 40).
4. **`AUDIT_EXEMPT` grew beyond the catalogue's list** by seven entries, each with a
   written reason in `route-manifest.ts`: two MFA ceremony *starts* (only completions are
   decisions), `account/avatar/upload-url` (a presign, like the two the catalogue already
   exempted), `DELETE /studio/drafts/:id` (no catalogue event exists for discarding a
   private draft), plus `admin/payments/reconcile` and `advisories/:id/estimate` (reads
   with a POST verb).
5. **Broadcast routes append their own audit entry** rather than using the `audited()`
   wrapper, because the catalogue requires the entry's `seq` on the broadcast row and the
   wrapper appends after the handler returns. They carry the `vv.audited` tag, so the
   conformance suite still counts them as audited. `retract` and `patch-status` do use the
   wrapper.
6. **`CHAIN_VERIFIED` severity.** `AuditSpec` (Task 25) has no `severity`/`sevLevel` field,
   so a broken chain cannot be raised to `critical` through `audited()`. The breakage is
   reported in the entry's message and `details.state` instead. Fixing it properly means
   widening `AuditSpec` — a Task 25 file.
7. **Two register lines instead of one** in `routes/v1/index.ts` for Tasks 34, 36, 37 and
   40, because each of those tasks ships two route groups. The file is in every one of
   those deliverable lists.
8. **Per-route `schema.tags` were not retro-fitted.** The conformance suite enforces a 2xx
   response schema and a body schema where a route takes input, and checks the audit
   prefix; OpenAPI tagging stays centralised (Task 21's `jsonSchemaTransform`) rather than
   being added to ~15 route files, which the deliverable rules only permit for missing
   guards/wrappers/schemas.

## Issues found in earlier tasks (not fixed — outside these tasks' deliverables)

- **`apps/api/src/billing/ledger.ts` (Task 32)** casts `$5::ledger_reference`, but
  `journal_entries.reference_type` is a plain `text` column and no `ledger_reference` enum
  exists in `packages/db`. Every `LedgerService.post` would fail at runtime against a real
  database. One-word fix: drop the cast.
- **`ROLE_PERMISSIONS` (Task 19) vs the catalogue.** `security_analyst` holds neither
  `scans:review` (Task 35 says analysts have it) nor `content:moderate` (Task 36 assumes a
  moderating analyst). Routes are implemented against the real map; tests grant the
  permission explicitly where a case needs it. Reconciling the two means editing Task 19's
  `permissions.ts` and the Task 24 SQL hook that mirrors it.
- **`StripeClient.setDefaultPaymentMethod` (Task 32)** contains a dead ternary whose two
  branches are identical. Harmless, but it is noise in a money path.
