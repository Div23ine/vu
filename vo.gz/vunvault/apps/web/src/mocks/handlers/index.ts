import { authHandlers } from './auth';
import { consentHandlers } from './consent';
import { contactHandlers } from './contact';
import { newsletterHandlers } from './newsletter';
import { pentestHandlers } from './pentest';
import { publicContentHandlers } from './public-content';
import { storeHandlers } from './store';

/**
 * The single aggregated handler list.
 *
 * Later tasks append exactly one import and one spread here so the mock layer
 * stays reviewable at a glance.
 */
export const handlers = [
  ...authHandlers,
  ...pentestHandlers,
  ...publicContentHandlers,
  ...storeHandlers,
  ...newsletterHandlers,
  ...contactHandlers,
  ...consentHandlers,
];
