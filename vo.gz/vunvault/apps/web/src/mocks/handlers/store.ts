import { http, HttpResponse } from 'msw';
import { ProductView, type ProductView as ProductViewType } from '@vunvault/contracts';
import { products } from '@vunvault/contracts/fixtures/store';
import { formatInvoiceNumber } from '@vunvault/lib';

/**
 * Store mock handlers (Task 55).
 *
 *   GET  /api/v1/products             → 200 { data: ProductView[]; total }
 *   POST /api/v1/products/:id/purchase → 201 PurchaseResponse | 404
 *
 * The catalogue fixture IS the seeded product table (six licences, USD
 * cents, `settlementCurrency: "USD"`); every list response is validated
 * against the contract schema so fixture drift fails loudly. Purchases issue
 * a deterministic invoice (`VV-INV-<year>-<000n>` via the shared formatter) —
 * payment itself is Task 66's checkout, never this handler.
 */

let issued = 0;

function assertFixture(product: ProductViewType): void {
  const parsed = ProductView.safeParse(product);
  if (!parsed.success) {
    throw new Error(`products fixture drifted from ProductView: ${parsed.error.message}`);
  }
}

export const storeHandlers = [
  http.get('*/api/v1/products', () => {
    for (const product of products) assertFixture(product);
    return HttpResponse.json({ data: products, total: products.length });
  }),

  http.post('*/api/v1/products/:id/purchase', ({ params }) => {
    const id = String(params.id);
    const product = products.find((candidate) => candidate.id === id);
    if (product === undefined) {
      return HttpResponse.json({ error: 'not_found' }, { status: 404 });
    }
    issued += 1;
    const year = new Date().getUTCFullYear();
    return HttpResponse.json(
      {
        data: {
          invoiceId: `b1000000-0000-4000-8000-${String(issued).padStart(12, '0')}`,
          invoiceNumber: formatInvoiceNumber(year, issued),
          totalUsdCents: product.priceUsdCents,
          settlementCurrency: 'USD',
        },
      },
      { status: 201 },
    );
  }),
];
