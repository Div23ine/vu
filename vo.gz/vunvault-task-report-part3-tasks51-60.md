# VUNVAULT — Part 3 Task Report: Tasks 51–60

Repo: `/home/user/vunvault` (baseline `aca6dae` → `a66defe`, one commit per task).
Catalogue: `uploads/vunvault-task-catalogue-part-3.md`. Tracker: `part3-progress.md`.

**Milestone verification (after Task 60):** `pnpm verify` guards OK · `pnpm format:check` OK ·
`turbo run typecheck lint test --filter='!api' --concurrency=1` → **26/26 tasks** ·
api suite **856/856** · web suite **221 tests / 28 files** · every web task gate
(`typecheck`, `lint`, `test`) green at each commit.

**Environment limitation (disclosed once, applies to 56–60):** the production `next build`
now OOMs in this 1 GB sandbox (kernel SIGKILL during webpack sealing; V8 caps and
`experimental.webpackMemoryOptimizations` did not help; turbopack/webpack dev route compiles
stall >5 min). Routes through Task 55b were build-smoked live in earlier sessions. From Task 56
the runtime evidence is the vitest suite (MSW-backed, real api-client pipeline) + tsc + eslint;
a full build/route smoke should be re-run on a ≥2 GB machine at the next milestone. No
`next.config.ts` residue: every temp patch was restored and verified byte-identical
(`git diff --quiet`) before committing.

---

## Task 51 — Home page D: Academy tracks + Plans & Pricing (`8963da0`)

Academy strip and `PricingPlans` section for the home route. `PLANS` rendered through
`formatUsdWhole(cents)` (`$299`, `$899`, `$2,499`); pricing CTA → `/services#pricing`.
**Task 51 complete. Files created:** home-d components/styles/tests per deliverables.
**Files modified:** home assembly stub. **Dependencies added:** none.

## Task 52 — Home page E + final home route assembly (`07b38f5`)

Press band, contributors, contact strip; assembles `(marketing)/page.tsx` from the Task 47–51
sections and **deletes the temporary `src/app/page.tsx`** placeholder (route collision).
`#get-started` anchor target with `scroll-mt-24`; the `Proactive Security Ecosystem` header +
Security Advisory / Network Mapping side cards around the Task 50 widget belong to this task
and were built here. Absolute-positioned section title reproduced per markup.
**Task 52 complete. Files created/modified/deleted:** per deliverables (deletion disclosed above).
**Dependencies added:** none.

## Task 53 / 53b — About page A/B (`ceb535d`, `e5324ef`)

About hero + mission/vision/pillars/closing band (53); core-team cards and the live system
telemetry panel (53b) reusing the Task 50 UTC clock + rotation pattern. `useReveal` lives in
`about-hero.tsx` and is shared by later pages.
**Tasks 53/53b complete. Dependencies added:** none.

## Task 54 / 54b — Services page A/B (`8954d41`, `179fe0f`)

Hero + sticky tabs + inline OSINT CLI (delegates to the Task 48 `useScanSimulation` engine) +
core services (54); detailed pricing, academy strip, request band (54b).
**Conflict resolution (54b, disclosed):** the prototype embeds a 4-plan pricing markup while
Behaviour+Tests specify the 3 shared plans ($299/$899/$2,499) with category-query CTAs — per
the catalogue's own precedence (behaviour/tests win for logic) the 3-plan set was built;
`buy` CTAs route to `/portal/billing`.
**Tasks 54/54b complete. Dependencies added:** none.

## Task 55 / 55b — Products page A/B (`6a6596a`, `6396f5e`)

API-driven premium catalogue via `useProducts`/`usePurchaseProduct` (55). Buy Now flow:
anonymous → `/login?next=/products`; client → `POST /products/:id/purchase` →
`/portal/billing?invoice=<invoiceId>` (paid in Task 66); staff → warn toast
`Client accounts only`. Free resources + toolbox shell (55b): the prototype terminal is
ported, `scan` delegates to the Task 48 engine, `buy` announces and navigates to
`/portal/billing`, `downloads` print lines but fetch nothing (`TODO(content)` — no operator
assets); Download buttons render disabled with explanatory `title`.
**Tasks 55/55b complete. Dependencies added:** none.

## Task 56 — Blog: list, article reader, safe markdown, newsletter (`27a2d2d`)

**Created:** `blog/page.tsx` (client composer: CveTicker → BlogHero → FeaturedReport →
NewsList → NewsletterForm → ScannerCta), `blog/[slug]/page.tsx` (edge route),
`_components/{blog-hero,category-pills,featured-report,news-list,newsletter-form,article-reader,safe-markdown}.tsx`,
`_hooks/use-blog.ts`, `_styles/blog.css`, `mocks/handlers/newsletter.ts`,
`blog/blog.test.tsx`, `blog/[slug]/article.test.tsx`.
**Modified (consequential, disclosed):** `mocks/handlers/public-content.ts` (+`q`/`category`
filtering mirroring the API repo's ILIKE-over-title/excerpt/tags semantics, +`GET /content/:slug`
detail route) and `mocks/handlers/index.ts` (spread).

Decisions & deviations:
- **`SafeMarkdown`** is a closed line-based renderer → React elements only: `##`/`###`,
  paragraphs, `-` lists, `>` quotes; inline `**bold**`, `*italic*`, `` `code` ``, links with
  http(s)-only hrefs + `rel="noopener noreferrer nofollow" target="_blank"`. Raw HTML renders
  inert (React escaping — asserted: `<script>`/`<img onerror>` become text, `javascript:`/`data:`
  links drop to plain text). No `dangerouslySetInnerHTML` anywhere.
- `[slug]/page.tsx`: `runtime = 'edge'`, Next 15 async `params`, `fetch(…, { next: { revalidate: 60 } })`,
  `notFound()` on 404 **and** on contract-parse failure, `generateMetadata` = title/excerpt/OG image,
  exported `fetchArticle(slug)` for tests.
- Hooks live in `use-blog.ts` (`useBlogList` with the full filter surface, `useBlogCategories`,
  `useFeaturedReport`, `useBlogDetail`, `useNewsletterSubscribe`) — the Task 49 `usePublicContent`
  hook keeps its fixed `{ pageSize, sort }` home-grid shape and was not touched. Detail query key
  is local (`['content','detail',slug]`) because the Task 7 factory has no content-detail slot.
- Featured report = first row of `sort=priority` (fixture CRITICAL post "Zero-Day Exploit
  Trends…"), separate query. Pills = `All` + `BLOG_CATEGORY_LABELS` present in the **unfiltered**
  catalogue snapshot (a dedicated query, so pills never shrink while a filter is active —
  interpretation disclosed). 250 ms debounce in the hero (local input state); counter shows the
  list query's `total` (`Showing N reports`, verbatim singular/plural as the prototype).
- Cards reuse the Task 49 `ArticleCard` untouched; the severity chip
  (`vv-chip--critical|high|medium|low`, labels from `SEVERITY_CHIP_LABELS`) is pinned over the
  thumbnail by a `vv-news-cell` wrapper instead of modifying Task 49's component.
- Newsletter: RHF+Zod over `NewsletterSubscribeBody` (source `blog`); 202 → toast
  `{ ok, "Check your inbox", "We sent a confirmation link to your email address." }` + field
  cleared; note element flips `is-ok`/`is-err`.
- Mock detail bodies are **synthesised** (`synthesiseBody`, labelled "Mock body…") — fixtures
  carry no `bodyMd` and the real one lives in the DB; disclosed scaffolding, never UI copy.
- `.vv-blog-pill` rules authored (catalogue names the class in reduced-motion but embeds no
  rule block); `.vv-news-grid`/`.vv-article-*` arrive via `ArticleCard`'s own stylesheet import.

**Task 56 complete. Files created:** the 12 listed above. **Files modified:**
`mocks/handlers/public-content.ts`, `mocks/handlers/index.ts` (both disclosed).
**Dependencies added:** none.

## Task 57 — Contact: hero, secure request form, direct channels (`5c3db64`)

**Created:** `contact/page.tsx` (server; `<Suspense>` around the form),
`_components/{contact-hero,contact-form,contact-cards}.tsx`, `_hooks/use-contact.ts`,
`_styles/contact.css`, `mocks/handlers/contact.ts`, `contact/contact.test.tsx`.
**Modified:** `mocks/handlers/index.ts`.

Decisions & deviations:
- Form = RHF + Zod `ContactBody` (contracts) with the planner's verbatim validation copy;
  consent uses the contract's `CONSENT_REQUIRED_MESSAGE` (`Consent is required`). The
  **honeypot** `website` rides in the extended schema (the bare contract would strip it) and is
  asserted present in the payload; the mock mirrors the real API exactly — a filled honeypot
  answers 201 with a throwaway id and stores nothing.
- Status banners verbatim: `Request received — reference REQ-XXXXXX.` (+ category sentence),
  400/429/network copies as specified; `role="status"` (ok) / `role="alert"` (err) — note these
  roles take no accessible name from content, so tests query by text.
- The reference JS's per-category success sentences are **truncated after journalist/
  whistleblower**; those two were rebuilt with the catalogue-mandated queue→API wording
  (`An administrator will review it shortly.`) and the remaining three categories use that
  sentence as fallback — disclosed planner-gap fill.
- `?category=<enum>` preselect (unknown values ignored → placeholder); `?category` arrives via
  `useSearchParams` inside `<Suspense>`. PGP link → `/vunvault-pgp.asc` (root-relative — the
  prototype's bare `vunvault-pgp.asc` would resolve under `/contact/`; operator asset, not created).
- `.zero-day-label/-input` rules authored (they live in the prototype's zero-day sheet which no
  task embeds) following the portal's `vbb-input` idiom; press-workflow steps keep
  `user-management.html`/`admin.html` as verbatim **text** (code chips), never as hrefs.

**Task 57 complete. Files created:** the 7 listed above. **Files modified:**
`mocks/handlers/index.ts`. **Dependencies added:** none.

## Task 58 — Cookie consent banner + preference panel (`7cef74e`)

**Created:** `_components/consent/{consent-banner.tsx,consent-store.ts,consent.test.tsx}`,
`_hooks/use-record-consent.ts`, `_styles/consent.css`, `mocks/handlers/consent.ts`.
**Modified:** `_components/../layout.tsx` (marketing layout mounts `<ConsentBanner />`),
`mocks/handlers/index.ts`.

Decisions & deviations:
- Mount rules exactly per spec: `vunvault:preloader-done` (Task 44 gate dispatches it on
  `document`) **or** 6 s fallback, suppressed when the decision is known — the store
  initialises from the readable `vv_consent=1` cookie (module scope + `ConsentProvider`
  re-check on mount). In-memory Zustand only; **no browser storage**.
- Recording: `POST /api/v1/consent` `{ categories, policyVersion: "1" }` via the contract's
  `CONSENT_ACCEPT_ALL` / `CONSENT_ESSENTIAL_ONLY`; 204 → `is-leaving` → unmount after 400 ms →
  `vv-consent-open` removed from `<body>`; any failure keeps the banner open + toast
  `{ warn, "Could not save your choice", "Please try again." }` (undecided).
- Customize panel: quick-actions hidden, first switch focused, aria-live announcements
  (`Preference panel opened` / `Returned to quick choices` / `<Name> cookies enabled|disabled`),
  live `On`/`Off` chips, necessary switch checked+disabled. Escape does **not** dismiss.
- **Disclosed conflict:** markup carries `aria-modal="true"` while the behaviour note calls the
  dialog non-modal — markup kept verbatim (no focus trap is specified and Escape must not close).
- The dialog is absent from the DOM until shown (mounted with `is-visible` on a 20 ms second
  tick so the CSS transition still runs) — keeps "appears after the event" honestly testable.
- `ConsentProvider` is a plain function returning `children` (a `.ts` deliverable can't hold JSX).
- **Backend follow-up (per the catalogue's own instruction):** the real API does **not** yet set
  the readable `vv_consent=1` cookie on `POST /api/v1/consent` — one-line follow-up when the API
  is next touched; until then the 204 is the success signal and the decision is per-page-load.

**Task 58 complete. Files created:** the 6 listed above. **Files modified:**
`(marketing)/layout.tsx`, `mocks/handlers/index.ts`. **Dependencies added:** none.

## Task 59 — Login page (`01fa3e5`)

**Created:** `(auth)/_components/{auth-background.tsx,oauth-buttons.tsx}`,
`login/{page.tsx,_components/login-card.tsx,_hooks/use-login.ts}`, `_styles/auth.css`,
`login/login.test.tsx`, **plus** `login/_store/mfa-dialog-store.ts` —
**disclosed cross-task file:** Task 60's deliverables list it as the "Zustand store used by
Task 59" and Task 59's card must call `useMfaDialog().open(...)`; it is created here minimally
and extended by Task 60 (`MfaUiMethod` gains `recovery`).
**Modified:** `(auth)/layout.tsx` (pass-through → full-screen shell: `AuthBackground` +
centred `.vv-auth-overlay`).

Decisions & deviations:
- Card root is `<main aria-labelledby="vvLoginTitle">` — the prototype's
  `role="dialog" aria-modal` is wrong for a full page and the planner's note says so; asserted.
- Form = RHF+Zod with a **form-level schema** carrying the planner's verbatim messages
  (`Email address is required.` / `Enter a valid email address.` / `Password is required.` /
  `Password must be at least 8 characters.` — contract minimum 8, not the prototype's 6);
  the contracts `LoginBody` itself is untouched.
- `?next=` sanitised **on the server** (`safeNextPath`: single leading `/`, rejects `//` and
  `\` tricks) before the card sees it; success → `setQueryData(queryKeys.session(), user)` +
  `router.replace(next ?? homeFor(role))`. `mfaRequired` → store hand-off (no navigation).
  401 → `{ crit, "Sign-in failed", "Incorrect email or password." }` (never says which);
  429 → `{ warn, "Too many attempts", … }`.
- OAuth buttons: `window.location.assign(API + '/api/v1/auth/oauth/<provider>/start?next=…')` —
  exact URL asserted in tests (providers `google`/`github`/`microsoft`). The prototype's
  "handshake would start here" toast is gone.
- `?error=` codes → the five verbatim toast messages; `?mfa=1` → dialog opens immediately with
  pinned `["totp","webauthn"]`.
- `use-login.ts` deliberately has **no** `'use client'` directive so the server route can import
  `safeNextPath` from it (a client-directive module would import as a client reference).
- Authored CSS disclosed in-file: the prototype's page-level custom properties
  (`--auth-card-w`, `--txt-1..4`, `--line-glass*`) scoped to `.vv-auth-overlay` with values
  matching the dark literals the embedded blocks already use; truncated keyframes
  (`vvCardIn`, `vvShake`, `spin`) completed; overlay layout authored.
- Planner's own note kept: the "Zero-knowledge credential handling" legal line is verbatim
  prototype marketing copy — **flagged to the product owner** (the platform is not zero-knowledge).

**Task 59 complete. Files created:** the 7 above (incl. the disclosed store).
**Files modified:** `(auth)/layout.tsx`, `mocks/handlers/index.ts` untouched (login handler
already existed from Task 42). **Dependencies added:** none.

## Task 60 — MFA verification dialog (`a66defe`)

**Created:** `login/_components/{mfa-dialog.tsx,otp-input.tsx}`, `login/_hooks/use-mfa.ts`,
`login/_lib/webauthn-client.ts`, `login/mfa.test.tsx`.
**Modified:** `login/_store/mfa-dialog-store.ts` (owner task: `MfaUiMethod = MfaMethod | 'recovery'`),
`_styles/auth.css` (appended OTP rules per deliverables), `login/page.tsx` (mounts
`<MfaDialog />`; `login-card.tsx` untouched as mandated).

Decisions & deviations:
- Dialog semantics per spec: `role="dialog"` + `aria-modal` + `aria-labelledby="vvOtpTitle"`,
  Tab focus trap (visibility-filtered), Escape/Close/Back all clear the store and call nothing
  on the API; focus restored to the opener; body gets `vv-modal-open` (which dims the login
  card via CSS — the prototype toggled `.is-dimmed` on the card directly and the card is
  off-limits for this task).
- Default method order `webauthn` (auto-prompted once) → `totp` → `email_otp`; the switcher
  shows only offered methods, with **recovery always offered** as the client-side fallback
  (the API enum can't carry it — interpretation disclosed).
- Six-box UX ported fully: digits-only, auto-advance, backspace-steps-back (clearing the
  previous box), arrow navigation, paste fills and **submits once** (pending guard); no test-OTP
  toasts, no console logging, no storage. `otp-input.tsx` is standalone for Task 62 reuse.
- Verbatim errors: `Incorrect code. Please check the digits and try again.` (+ shake, which
  `prefers-reduced-motion` removes), `Please enter all 6 digits.`,
  `Security key request was cancelled.` (NotAllowedError keeps the dialog open);
  410/`challenge_expired` (incl. the five-failure deletion) → close + `{ warn, "Session expired",
  "Please sign in again." }`. A network-failure sentence was planner-silent — authored
  `Verification failed. Please try again.` (disclosed).
- **Success-view copy conflict resolved for the planner:** the Behaviour section explicitly
  dictates verbatim `Verification successful` / `Redirecting to VUNVAULT…`, superseding the
  prototype markup's `Identity verified` / `Redirecting you to your dashboard…`; navigation
  fires after the 1.4 s success-bar animation: `setQueryData(session)` → close →
  `replace(next ≠ '/' ? next : homeFor(role))`. Staff verified via **recovery** (session stays
  aal1) → `/login?error=mfa_required` (staff detected via `homeFor(role).startsWith('/admin')`;
  `SessionUser` carries no `aal` field — interpretation disclosed).
- Email OTP: `POST /mfa/email-otp` on entering the method (open or switch), masked target
  (`re••@example.com`, prototype's `maskEmail` ported), Resend with **60 s** cooldown
  (`Resend in {n}s`, planner text — the prototype JS said 30; behaviour wins), interval-based
  ticker (deterministic under fake timers).
- Recovery: normalise (trim/uppercase/strip spaces) then validate
  `^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$`; invalid format reuses the incorrect-code sentence
  (planner-silent, disclosed); single centred mono input (authored `.vv-recovery`).
- WebAuthn: `webauthn-client.ts` bridges JSON↔ArrayBuffer (base64url challenge/allowCredentials
  in; id/rawId/clientDataJSON/authenticatorData/signature/userHandle out),
  `navigator.credentials.get` mocked in tests; assertion body encoding asserted byte-exact.
- MFA endpoints are mocked **inside `mfa.test.tsx`** via `server.use` (the shared auth handler
  file is not in this task's deliverables and was left untouched).
- Authored CSS tail disclosed in-file: truncated responsive block + `vvShakeStrong`/`vvFadeUp`/
  `vvSuccessPop`/`vvSuccessBar` keyframes + the `[hidden]` guard (view classes set
  `display:flex`, which would outrank the UA hidden rule) + `body.vv-modal-open` dimming.

**Task 60 complete. Files created:** the 5 above. **Files modified:** `mfa-dialog-store.ts`,
`auth.css`, `login/page.tsx`. **Dependencies added:** none.

---

## Cross-task notes

- **Zero new dependencies** across 51–60 (RHF/Zod/Radix/Zustand/MSW all pre-existing).
- **No browser storage** anywhere (58's cookie read is the API-set decision flag, not app state).
- Operator assets still pending: `public/brand/logo.svg` (header + login card) and
  `public/vunvault-pgp.asc` (contact PGP download) — 404s expected until supplied.
- Routes not yet built but already linked: `/signup` (61), `/forgot-password` (63),
  `/newsletter/confirm` (63), `/privacy` + `/cookie-policy` (confirm owner in 61–65),
  `/portal/billing` (66, Part 4), `/academy` exists (51 CTA target `/services#pricing` used
  where the prototype pointed at payment.html — 55b/54b resolutions).
- Prep for Task 66 (Part 4, awaiting catalogue upload): `notes/task66-prep.md` maps the entire
  billing surface it will consume (routes, contracts, fixtures, `?invoice=` entry point from
  Task 55's Buy Now).
