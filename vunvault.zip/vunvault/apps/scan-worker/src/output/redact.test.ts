import { describe, expect, it } from 'vitest';
import { REDACTED, Redactor, REDACTION_PATTERNS, redact } from './redact';

/**
 * Redaction tests (Task 85). Every pattern in the table gets a sample, and each
 * assertion checks that the SECRET SUBSTRING is gone — not merely that
 * `[REDACTED]` appeared somewhere, which a broken pattern could also produce.
 *
 * The two negative cases matter as much as the positives: email addresses are
 * legitimate finding evidence and must survive, and a long random word that is
 * not near a secret keyword must not be eaten. Over-redaction destroys the
 * report.
 */

const SECRET_SAMPLES: readonly { id: string; input: string; secret: string }[] = [
  {
    id: 'authorization-header',
    input: 'Authorization: Bearer abc123def456ghi789',
    secret: 'abc123def456ghi789',
  },
  {
    id: 'authorization-basic',
    input: 'authorization: basic dXNlcjpwYXNzd29yZA==',
    secret: 'dXNlcjpwYXNzd29yZA==',
  },
  {
    id: 'cookie-header',
    input: 'Cookie: vv_session=9f2c1ab7e3d54f6880; theme=dark',
    secret: '9f2c1ab7e3d54f6880',
  },
  {
    id: 'set-cookie-header',
    input: 'Set-Cookie: token=abc123xyz789secret; HttpOnly',
    secret: 'abc123xyz789secret',
  },
  {
    id: 'jwt',
    input: 'got eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N',
    secret: 'eyJhbGciOiJIUzI1NiJ9',
  },
  {
    id: 'aws-access-key',
    input: 'found AKIAIOSFODNN7EXAMPLE in the response',
    secret: 'AKIAIOSFODNN7EXAMPLE',
  },
  {
    id: 'aws-secret-key',
    input: 'aws_secret_access_key = wJalrXUtnFEMI7K8MDENG9bPxRfiCYEXAMPLEKEY',
    secret: 'wJalrXUtnFEMI7K8MDENG9bPxRfiCYEXAMPLEKEY',
  },
  {
    id: 'github-token',
    input: 'leaked ghp_16C7e42F292c6912E7710c838347Ae178B4a',
    secret: 'ghp_16C7e42F292c6912E7710c838347Ae178B4a',
  },
  {
    id: 'slack-token',
    input: 'xoxb-123456789012-1234567890123-AbCdEfGhIjKlMnOpQrStUvWx',
    secret: 'xoxb-123456789012',
  },
  {
    id: 'google-api-key',
    input: 'AIzaSyA1234567890abcdefghijklmnopqrstuv appeared in config',
    secret: 'AIzaSyA1234567890abcdefghijklmnopqrstuv',
  },
  {
    id: 'stripe-key',
    input: 'sk_live_4eC39HqLyjWDarjtT1zdp7dc was returned',
    secret: 'sk_live_4eC39HqLyjWDarjtT1zdp7dc',
  },
  {
    id: 'url-credentials',
    input: 'connecting to https://admin:Sup3rS3cret@db.internal.test:5432/app',
    secret: 'Sup3rS3cret',
  },
  {
    id: 'keyword-value',
    input: 'password = hunter2example',
    secret: 'hunter2example',
  },
  {
    id: 'keyword-value-token',
    input: 'API_KEY: 8f14e45fceea167a5a36dedd4bea2543',
    secret: '8f14e45fceea167a5a36dedd4bea2543',
  },
];

describe('redact — every pattern in the table', () => {
  it.each(SECRET_SAMPLES)('$id removes the secret', ({ input, secret }) => {
    const output = redact(input);
    expect(output).not.toContain(secret);
    expect(output).toContain(REDACTED);
  });

  it('keeps the key name for a key=value pattern', () => {
    expect(redact('password = hunter2example')).toContain('password');
    expect(redact('Authorization: Bearer abc123')).toMatch(/^Authorization:\s*Bearer\s*\[REDACTED\]$/i);
  });

  it('keeps the host when URL credentials are stripped', () => {
    const output = redact('https://admin:Sup3rS3cret@db.internal.test:5432/app');
    expect(output).toContain('db.internal.test:5432/app');
    expect(output).toContain('://[REDACTED]@');
  });

  it('is idempotent', () => {
    for (const sample of SECRET_SAMPLES) {
      const once = redact(sample.input);
      expect(redact(once)).toBe(once);
    }
  });

  it('does NOT redact an email address (legitimate finding evidence)', () => {
    const input = 'contact security@horizonsacco.co.ke for disclosure';
    expect(redact(input)).toBe(input);
  });

  it('does NOT redact ordinary long words with no secret keyword nearby', () => {
    const input = 'Scanning Supercalifragilisticexpialidocious on port 443';
    expect(redact(input)).toBe(input);
  });

  it('does NOT redact a plain hostname or IP', () => {
    const input = 'Nmap scan report for api.horizonsacco.co.ke (41.90.64.199)';
    expect(redact(input)).toBe(input);
  });

  it('exports the table as data for the server-side redactor to mirror', () => {
    expect(REDACTION_PATTERNS.length).toBeGreaterThan(10);
    for (const pattern of REDACTION_PATTERNS) {
      expect(pattern.id).toMatch(/^[a-z-]+$/);
      expect(pattern.re).toBeInstanceOf(RegExp);
      expect(pattern.re.global).toBe(true);
    }
  });
});

describe('Redactor — multi-line PEM blocks', () => {
  const KEY_BLOCK = [
    'Found a key on the target:',
    '-----BEGIN RSA PRIVATE KEY-----',
    'MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MhgHcTz6sE2I2yPB',
    'aFDrBz9vFqU5yQXmNbHcTdWsLk0eJqN7YwXvBpR1sZmEfGhIjKlMnOpQrStUvWxY',
    '-----END RSA PRIVATE KEY-----',
    'Continuing the scan…',
  ];

  it('redacts every line of the block across separate push calls', () => {
    const redactor = new Redactor();
    const output = KEY_BLOCK.map((line) => redactor.push(line));

    // The surrounding lines survive.
    expect(output[0]).toBe('Found a key on the target:');
    expect(output[5]).toBe('Continuing the scan…');

    // The markers and every body line are gone.
    for (const line of output.slice(1, 5)) {
      expect(line).toBe(REDACTED);
    }
    expect(output.join('\n')).not.toContain('MIIEpAIBAAKCAQEA');
    expect(output.join('\n')).not.toContain('BEGIN RSA PRIVATE KEY');
    expect(output.join('\n')).not.toContain('END RSA PRIVATE KEY');
  });

  it('tracks the block state and closes on END', () => {
    const redactor = new Redactor();
    expect(redactor.inPrivateKeyBlock).toBe(false);
    redactor.push('-----BEGIN EC PRIVATE KEY-----');
    expect(redactor.inPrivateKeyBlock).toBe(true);
    redactor.push('MHQCAQEEIBkg');
    expect(redactor.inPrivateKeyBlock).toBe(true);
    redactor.push('-----END EC PRIVATE KEY-----');
    expect(redactor.inPrivateKeyBlock).toBe(false);
    // After the block, ordinary lines are processed normally again.
    expect(redactor.push('plain output line')).toBe('plain output line');
  });

  it('a one-line key does not leave the redactor stuck', () => {
    const redactor = new Redactor();
    const line = '-----BEGIN PRIVATE KEY----- MIIEvQIBADAN -----END PRIVATE KEY-----';
    expect(redactor.push(line)).toBe(REDACTED);
    expect(redactor.inPrivateKeyBlock).toBe(false);
    expect(redactor.push('next line')).toBe('next line');
  });

  it('still applies the stateless table outside a block', () => {
    const redactor = new Redactor();
    expect(redactor.push('password=hunter2example')).toBe(`password=${REDACTED}`);
  });

  it('an unclosed block keeps redacting to end of stream (fail closed)', () => {
    const redactor = new Redactor();
    redactor.push('-----BEGIN OPENSSH PRIVATE KEY-----');
    for (let index = 0; index < 50; index += 1) {
      expect(redactor.push(`b64line${index}`)).toBe(REDACTED);
    }
    expect(redactor.inPrivateKeyBlock).toBe(true);
  });
});
