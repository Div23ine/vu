# Part 3 run — progress tracker (Tasks 40b → 65)

Order required by the catalogue: 40 → **40b → 40c → 40d → 40e** → 41 → 42 → … → 65.
(Executed order in practice: 41 ran before 40b–40e on instruction; 40b–40e completed in the
previous session — see `vunvault-task-report-part3-tasks-40b-40e.md`.)

| Task | Layer | Title | Status |
|---|---|---|---|
| 40b | L4 | Marketing backend addendum A: products, entitlements, newsletter, richer public content (schema + contracts) | **complete** |
| 40c | L4 | Marketing backend addendum B: public content detail, product catalogue + purchase + entitlements, newsletter (routes) | **complete** |
| 40d | L4 | Auth addendum A: signup with email-OTP verification, forgot / reset password | **complete** |
| 40e | L4 | Auth addendum B: OAuth sign-in (Google, GitHub, Microsoft) via Supabase PKCE | **complete** |
| 41 | L5 | Next.js 15 app skeleton | **complete** (see vunvault-task-report-part3-task41.md) |
| 42 | L5 | Client runtime: providers, API bootstrap, session store, MSW mock layer | **complete** (`24b08ac`) |
| 43 | L5 | Edge middleware (nonce CSP, route guards), permission helpers, server session, error pages | **complete** (`417dd3e`) |
| 44 | L5 | Marketing layout: header, mobile drawer, auth-aware nav, footer variants, preloader gate | **complete** (`414886b`) |
| 45 | L5 | Client portal layout + Request PenTest dialog | **complete** (`04f5abc`) |
| 46 | L5 | Admin layout: Command Center header, permission-filtered nav, staff guard | **complete** (`aa45b75`) |
| 47 | L6 | Home page A: hero + Live Attack Surface + CVE ticker | **complete** (`03891c9`) |
| 48 | L6 | Free Scanner: CTA banner, terminal dialog, simulated scan engine | **complete** (`25803b0`) |
| 49 | L6 | Home page B: attack-surface mapping, rotating Insights grid, segments | **complete** (`569a0ce`) |
| 50 | L6 | Home page C: Zero-Day Exploit Tracking dashboard widget | **complete** (`2a5eb9f`) |
| 51 | L6 | Home page D: Academy tracks and Plans & Pricing | **complete** (`8963da0`) |
| 52 | L6 | Home page E: Press, Contributors, Contact — and final home route assembly | **complete** (`07b38f5`) |
| 53/53b | L6 | About page A/B | **complete** (`ceb535d`, `e5324ef`) |
| 54/54b | L6 | Services page A/B | **complete** (`8954d41`, `179fe0f`) |
| 55/55b | L6 | Products page A/B | **complete** (`6a6596a`, `6396f5e`) |
| 56 | L6 | Blog list + detail + newsletter | **complete** (`27a2d2d`) |
| 57 | L6 | Contact page | **complete** (`5c3db64`) |
| 58 | L6 | Cookie consent banner | **complete** (`7cef74e`) |
| 59 | L7 | Login page | **complete** (`01fa3e5`) |
| 60 | L7 | MFA challenge dialog | **complete** (`a66defe`) |
| 61 | L7 | Signup page A | pending — **next** |
| 62 | L7 | Signup page B | pending |
| 63 | L7 | Accept-invite, forgot/reset password, newsletter-confirm | pending |
| 64 | L7 | Client onboarding wizard A | pending |
| 65 | L7 | Client onboarding wizard B | pending |

Full details for 42–50: `vunvault-task-report-part3-tasks42-50.md`.
Full details for 51–60: `vunvault-task-report-part3-tasks51-60.md`.

## Environment notes (this sandbox)
- Node 22 + pnpm 9.15.0 must be reinstalled to `/tmp/node22` each session: `npm i node@22 && npm i -g pnpm@9.15.0` with `PATH=/tmp/node22/node_modules/node/bin:$PATH`.
- `apps/api` typecheck needs `NODE_OPTIONS=--max-old-space-size=1200..1536` (1 GB sandbox).
- `turbo run <task> --concurrency=1` to avoid OOM.
- `next dev` (turbopack) is impractically slow here — smoke with `next build` + `next start` + fetch instead.
- **Since Task 56 the production `next build` OOMs in this sandbox** (SIGKILL during webpack sealing; only ~800 MB headroom, `NODE_OPTIONS` caps and `webpackMemoryOptimizations` do not help; webpack-dev route compiles also stall >5 min). Runtime smokes for 56+ are deferred to a normal-RAM machine; the authoritative gates here are `pnpm --filter web typecheck` + `lint` + `vitest` (all green) — this is an environment limit, not an app regression (routes ≤55b built and smoked fine).
- `pnpm dlx msw init` pulls msw 3.x — use `pnpm exec msw init apps/web/public/` inside `apps/web` (worker must match msw 2.15.0).
- The repo is now a git checkout (baseline `aebfc56` + one commit per task, husky hooks ACTIVE). The workspace-aware lint-staged runner (`scripts/lint-staged-eslint.mjs`) is required for commits touching files with `@next/next/*` disable directives.
- Baseline after Task 60: repo-wide 26/26 non-api turbo tasks + api 856/856, web **221 tests / 28 files** (≈1497 tests repo-wide).

## Consequential edits outside deliverable lists (disclose in each report)
- (Task 40) `apps/api/src/plugins/infra.test.ts` — one `SECRET_NAMES` list entry.
- (Task 41) `packages/ui/src/components/*.tsx` ×12 `'use client'`; `apps/web/tsconfig.json` (Next's mandatory rewrite); `apps/web/eslint.config.mjs`; `.gitignore`.
- (Task 42) `apps/web/eslint.config.mjs` + `.gitignore` — generated `mockServiceWorker.js` ignored by both.
- (Task 45) `scripts/lint-staged-eslint.mjs` + `.lintstagedrc.json` — workspace-aware pre-commit eslint (fixes latent root-config bug affecting `packages/ui/logo.tsx` too).
- (Task 48) `apps/web/src/app/(marketing)/_components/site-footer.tsx` — one-line `matchMedia` guard.
- (Task 56) `apps/web/src/mocks/handlers/public-content.ts` — extended with `q`/`category` filtering and the `GET /content/:slug` detail route (deliverables listed only `newsletter.ts`).
- (Task 59) `apps/web/src/app/(auth)/login/_store/mfa-dialog-store.ts` — created ahead of its owner: Task 60's deliverables list names it "Zustand store used by Task 59"; Task 60 extended it (`MfaUiMethod` += `recovery`).

## Open items for Task 61+
- Task 61/62 (Signup A/B) reuse the Task 59 auth shell + `oauth-buttons.tsx`; Task 62 reuses `otp-input.tsx` (its header says so).
- Task 63 builds `/accept-invite`, `/forgot-password`, `/reset-password`, `/newsletter/confirm` — links to `/signup`, `/forgot-password` and the newsletter confirm flow already exist (56/59).
- `/privacy` and `/cookie-policy` are linked from the consent banner (58) but not yet routed — confirm which task owns them (61–65 specs) and note the 404s until then.
- Backend follow-up (from Task 58 behaviour): the real `POST /api/v1/consent` does NOT yet set the readable `vv_consent=1; Max-Age=31536000; SameSite=Lax; Secure` cookie — one-line API follow-up when the API is next touched; until then the consent decision is per-page-load (in-memory), exactly as the catalogue's interim instruction allows.
- Mock detail bodies (`public-content.ts` synthesiseBody) are labelled scaffolding — swap for real fixture `bodyMd` if fixtures ever gain one.
- Operator asset still missing: `apps/web/public/brand/logo.svg` (404s are expected until copied in; login card + header both reference it).
- Production `next build` smoke debt: run a full build + route smoke (blog, blog/[slug], contact, login) on a ≥2 GB machine at the next milestone.
